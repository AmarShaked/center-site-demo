<?php
/**
 * Plugin Name: Center Core
 * Description: סוגי תוכן, הרשאות ושפות עבור אתר המרכז לתולדות הטבע במורשת ישראל.
 * Version: 0.1.0
 * Requires at least: 7.1
 * Requires PHP: 7.4
 * Text Domain: center-core
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

define( 'CC_CORE_DIR', __DIR__ );

foreach ( glob( CC_CORE_DIR . '/includes/*.php' ) as $cc_file ) {
	require_once $cc_file;
}
