<?php
/**
 * Settings → "הגדרות המרכז": everything the theme reads from options, editable
 * by the site owner without code (menus per language, forms, numbers, partners,
 * social links, legal entity).
 *
 * @package center-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Field definitions: option => [label, kind, extra].
 *
 * @return array
 */
function cc_settings_fields() {
	return array(
		'cc_nav_he'            => array( 'תפריט ראשי בעברית', 'post', 'wp_navigation' ),
		'cc_nav_en'            => array( 'תפריט ראשי באנגלית', 'post', 'wp_navigation' ),
		'cc_newsletter_form_he' => array( 'טופס ניוזלטר בעברית', 'post', 'wpcf7_contact_form' ),
		'cc_newsletter_form_en' => array( 'טופס ניוזלטר באנגלית', 'post', 'wpcf7_contact_form' ),
		'cc_booking_form_he'   => array( 'טופס הזמנת פעילות בעברית', 'post', 'wpcf7_contact_form' ),
		'cc_booking_form_en'   => array( 'טופס הזמנת פעילות באנגלית', 'post', 'wpcf7_contact_form' ),
		'cc_contact_form_he'   => array( 'טופס יצירת קשר בעברית', 'post', 'wpcf7_contact_form' ),
		'cc_contact_form_en'   => array( 'טופס יצירת קשר באנגלית', 'post', 'wpcf7_contact_form' ),
		'cc_page_center'        => array( 'עמוד "אודות המרכז"', 'post', 'page' ),
		'cc_page_research'      => array( 'עמוד "מחקר ופרסומים"', 'post', 'page' ),
		'cc_page_news'          => array( 'עמוד "כנסים וחדשות"', 'post', 'page' ),
		'cc_page_museum'        => array( 'עמוד "המוזיאון והאוספים"', 'post', 'page' ),
		'cc_page_support'       => array( 'עמוד "שותפות ותרומות"', 'post', 'page' ),
		'cc_page_about'         => array( 'עמוד המייסד', 'post', 'page' ),
		'cc_page_books'         => array( 'עמוד הספרים', 'post', 'page' ),
		'cc_page_contact'       => array( 'עמוד צור קשר', 'post', 'page' ),
		'cc_page_credits'       => array( 'עמוד קרדיטים', 'post', 'page' ),
		'cc_page_privacy'       => array( 'עמוד מדיניות פרטיות', 'post', 'page' ),
		'cc_page_terms'         => array( 'עמוד תנאי שימוש', 'post', 'page' ),
		'cc_page_accessibility' => array( 'עמוד הצהרת נגישות', 'post', 'page' ),
		'cc_social_youtube'    => array( 'קישור ליוטיוב', 'url', '' ),
		'cc_social_facebook'   => array( 'קישור לפייסבוק', 'url', '' ),
		'cc_legal_entity'      => array( 'שם הגוף המשפטי ומספרו (מוצג בכותרת התחתונה)', 'text', '' ),
		'cc_stats'             => array( 'המרכז במספרים: שורה לכל מספר, בפורמט מספר | תווית בעברית | תווית באנגלית', 'lines', 3 ),
		'cc_partners'          => array( 'שותפים: שורה לכל שותף, בפורמט שם | כתובת לוגו | קישור', 'lines', 3 ),
	);
}

/**
 * Parses "a | b | c" lines into arrays of exactly $cols trimmed cells.
 *
 * @param string $text Textarea value.
 * @param int    $cols Cells per line.
 * @return array
 */
function cc_parse_lines( $text, $cols ) {
	$rows = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
		$cells = array_map( 'trim', explode( '|', $line ) );
		if ( '' === $cells[0] ) {
			continue;
		}
		$rows[] = array_map( 'sanitize_text_field', array_slice( array_pad( $cells, $cols, '' ), 0, $cols ) );
	}
	return $rows;
}

/**
 * Registers the settings with sanitizers.
 */
function cc_register_settings() {
	foreach ( cc_settings_fields() as $name => $def ) {
		$kind = $def[1];
		$cols = (int) $def[2];
		register_setting(
			'cc_settings',
			$name,
			array(
				'sanitize_callback' => function ( $value ) use ( $kind, $cols ) {
					if ( 'post' === $kind ) {
						return (string) absint( $value );
					}
					if ( 'url' === $kind ) {
						return esc_url_raw( (string) $value );
					}
					if ( 'lines' === $kind ) {
						return is_array( $value ) ? $value : cc_parse_lines( $value, $cols );
					}
					return sanitize_text_field( (string) $value );
				},
			)
		);
	}
}
add_action( 'admin_init', 'cc_register_settings' );

/**
 * Adds the page under Settings (administrators only).
 */
function cc_settings_menu() {
	add_options_page( 'הגדרות המרכז', 'הגדרות המרכז', 'manage_options', 'cc-settings', 'cc_render_settings_page' );
}
add_action( 'admin_menu', 'cc_settings_menu' );

/**
 * Renders the settings page.
 */
function cc_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	echo '<div class="wrap"><h1>הגדרות המרכז</h1><form method="post" action="options.php">';
	settings_fields( 'cc_settings' );
	echo '<table class="form-table" role="presentation">';
	foreach ( cc_settings_fields() as $name => $def ) {
		list( $label, $kind, $extra ) = $def;
		$value = get_option( $name, '' );
		echo '<tr><th scope="row"><label for="' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'post' === $kind ) {
			$query = array( 'post_type' => $extra, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC', 'suppress_filters' => true );
			if ( 'page' === $extra && function_exists( 'pll_default_language' ) ) {
				$query['lang']             = pll_default_language();
				$query['suppress_filters'] = false;
			}
			$posts = get_posts( $query );
			echo '<select id="' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '"><option value="0">— ללא —</option>';
			foreach ( $posts as $p ) {
				echo '<option value="' . (int) $p->ID . '"' . selected( (int) $value, $p->ID, false ) . '>' . esc_html( $p->post_title ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'lines' === $kind ) {
			$text = implode( "\n", array_map( function ( $row ) {
				return implode( ' | ', (array) $row );
			}, (array) $value ) );
			echo '<textarea id="' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" rows="4" class="large-text code">' . esc_textarea( $text ) . '</textarea>';
		} else {
			echo '<input id="' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" type="' . ( 'url' === $kind ? 'url' : 'text' ) . '" class="regular-text" value="' . esc_attr( (string) $value ) . '">';
		}
		echo '</td></tr>';
	}
	echo '</table>';
	submit_button( 'שמירה' );
	echo '</form></div>';
}
