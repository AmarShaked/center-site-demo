<?php
/**
 * Taxonomies and their default terms (spec §8.13, §8.15).
 *
 * @package center-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Taxonomy definitions: slug => [object types, plural label, singular label, rewrite slug, default terms].
 *
 * @return array
 */
function cc_taxonomy_defs() {
	return array(
		'research_area'    => array( array( 'post', 'activity' ), 'תחומי מחקר', 'תחום מחקר', 'research-area', array( 'צבעים ומלאכות קדומות', 'רפואה בשמים וקטורת', 'חקלאות ומזון קדום', 'בעלי חיים ומסורות ישראל' ) ),
		'activity_type'    => array( array( 'activity' ), 'סוגי פעילות', 'סוג פעילות', 'activity-type', array( 'הרצאה', 'סדנה', 'השתלמות מורים', 'סיור', 'פעילות לתלמידים' ) ),
		'audience'         => array( array( 'activity' ), 'קהלי יעד', 'קהל יעד', 'audience', array( 'קהל רחב', 'מבוגרים וקבוצות', 'מורים', 'משפחות ותלמידים' ) ),
		'researcher_group' => array( array( 'researcher' ), 'קבוצות חוקרים', 'קבוצה', 'researcher-group', array( 'חוקרים ועמיתי מחקר', 'המועצה המדעית' ) ),
	);
}

/**
 * Registers the taxonomies.
 */
function cc_register_taxonomies() {
	foreach ( cc_taxonomy_defs() as $slug => $def ) {
		register_taxonomy(
			$slug,
			$def[0],
			array(
				'labels'            => array(
					'name'          => $def[1],
					'singular_name' => $def[2],
					'menu_name'     => $def[1],
					'add_new_item'  => 'הוספת ' . $def[2],
					'edit_item'     => 'עריכת ' . $def[2],
					'search_items'  => 'חיפוש ' . $def[1],
					'all_items'     => 'כל ' . $def[1],
				),
				'public'            => true,
				'hierarchical'      => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array( 'slug' => $def[3], 'with_front' => false ),
			)
		);
	}
}
add_action( 'init', 'cc_register_taxonomies', 5 );

/**
 * Creates the default terms if missing.
 */
function cc_seed_terms() {
	foreach ( cc_taxonomy_defs() as $slug => $def ) {
		foreach ( $def[4] as $name ) {
			if ( ! term_exists( $name, $slug ) ) {
				wp_insert_term( $name, $slug );
			}
		}
	}
}

/**
 * Activation: register everything, seed terms, flush rewrites.
 */
function cc_flush_on_activate() {
	cc_register_post_types();
	cc_register_taxonomies();
	cc_seed_terms();
	do_action( 'cc_activated' );
	flush_rewrite_rules( false );
}
register_activation_hook( CC_CORE_DIR . '/center-core.php', 'cc_flush_on_activate' );
