<?php
/**
 * Sections: hide a section whose query has no posts (spec §8.12), and split
 * events into upcoming and past (spec §9).
 *
 * @package center-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Removes a group with class cc-hide-when-empty when it lists no posts.
 *
 * @param string $content Rendered block HTML.
 * @param array  $block   Parsed block.
 * @return string
 */
function cc_hide_empty_section( $content, $block ) {
	if ( 'core/group' !== $block['blockName'] ) {
		return $content;
	}
	$class = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( false === strpos( ' ' . $class . ' ', ' cc-hide-when-empty ' ) ) {
		return $content;
	}
	// Post-template items carry class "wp-block-post " (note the space).
	return preg_match( '/class="[^"]*\bwp-block-post\s/', $content ) ? $content : '';
}
add_filter( 'render_block', 'cc_hide_empty_section', 10, 2 );

/**
 * Today in the site's timezone, Y-m-d.
 *
 * @return string
 */
function cc_today() {
	return wp_date( 'Y-m-d' );
}

/**
 * Query args for upcoming or past events.
 *
 * @param string $when 'upcoming' or 'past'.
 * @return array
 */
function cc_event_query_args( $when ) {
	$past = 'past' === $when;
	return array(
		'meta_key'   => 'cc_event_date', // phpcs:ignore WordPress.DB.SlowDBQuery
		'orderby'    => 'meta_value',
		'order'      => $past ? 'DESC' : 'ASC',
		'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery
			array(
				'key'     => 'cc_event_date',
				'value'   => cc_today(),
				'compare' => $past ? '<' : '>=',
				'type'    => 'DATE',
			),
		),
	);
}

/**
 * Query Loop blocks whose query attribute has ccEvents = upcoming|past.
 *
 * @param array    $query Query vars.
 * @param WP_Block $block Post-template block.
 * @return array
 */
function cc_event_query_vars( $query, $block ) {
	$when = isset( $block->context['query']['ccEvents'] ) ? $block->context['query']['ccEvents'] : '';
	if ( 'upcoming' === $when || 'past' === $when ) {
		$query = array_merge( $query, cc_event_query_args( $when ) );
	}
	return $query;
}
add_filter( 'query_loop_block_query_vars', 'cc_event_query_vars', 10, 2 );

/**
 * The event archive lists upcoming events; ?past=1 lists past ones.
 *
 * @param WP_Query $q Query.
 */
function cc_event_archive_query( $q ) {
	if ( is_admin() || ! $q->is_main_query() || ! $q->is_post_type_archive( 'event' ) ) {
		return;
	}
	$when = isset( $_GET['past'] ) ? 'past' : 'upcoming'; // phpcs:ignore WordPress.Security.NonceVerification
	foreach ( cc_event_query_args( $when ) as $key => $value ) {
		$q->set( $key, $value );
	}
}
add_action( 'pre_get_posts', 'cc_event_archive_query' );
