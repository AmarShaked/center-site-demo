<?php
/**
 * Roles: researchers (WP Authors) publish their own posts immediately; only the
 * site owner (administrator) edits researcher pages; activities, events and
 * exhibits are for administrators and editors (spec §6, §8.3).
 *
 * @package center-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Capability types per content type.
 *
 * @return array post type => [singular, plural]
 */
function cc_capability_types() {
	return array(
		'researcher' => array( 'cc_researcher', 'cc_researchers' ),
		'activity'   => array( 'cc_item', 'cc_items' ),
		'event'      => array( 'cc_item', 'cc_items' ),
		'exhibit'    => array( 'cc_item', 'cc_items' ),
	);
}

/**
 * Gives each content type its own capability type.
 *
 * @param array  $args Post type args.
 * @param string $slug Post type.
 * @return array
 */
function cc_post_type_caps( $args, $slug ) {
	$types = cc_capability_types();
	if ( isset( $types[ $slug ] ) ) {
		$args['capability_type'] = $types[ $slug ];
		$args['map_meta_cap']    = true;
	}
	return $args;
}
add_filter( 'cc_post_type_args', 'cc_post_type_caps', 10, 2 );

/**
 * Primitive capabilities for a capability type.
 *
 * @param string $plural Plural capability type.
 * @return string[]
 */
function cc_primitive_caps( $plural ) {
	return array(
		"edit_{$plural}",
		"edit_others_{$plural}",
		"edit_private_{$plural}",
		"edit_published_{$plural}",
		"publish_{$plural}",
		"read_private_{$plural}",
		"delete_{$plural}",
		"delete_others_{$plural}",
		"delete_private_{$plural}",
		"delete_published_{$plural}",
	);
}

/**
 * Grants the custom capabilities. Researchers: administrator only.
 * Items (activity/event/exhibit): administrator and editor.
 */
function cc_grant_caps() {
	$grants = array(
		'cc_researchers' => array( 'administrator' ),
		'cc_items'       => array( 'administrator', 'editor' ),
	);
	foreach ( $grants as $plural => $roles ) {
		foreach ( $roles as $role_name ) {
			$role = get_role( $role_name );
			if ( ! $role ) {
				continue;
			}
			foreach ( cc_primitive_caps( $plural ) as $cap ) {
				$role->add_cap( $cap );
			}
		}
	}
	update_option( 'cc_caps_version', 1 );
}
add_action( 'cc_activated', 'cc_grant_caps' );

/**
 * Re-grants if the plugin was updated without re-activation.
 */
function cc_maybe_grant_caps() {
	if ( 1 !== (int) get_option( 'cc_caps_version' ) ) {
		cc_grant_caps();
	}
}
add_action( 'init', 'cc_maybe_grant_caps', 20 );

/**
 * The published researcher entry linked to a WP user, if any.
 *
 * @param int $user_id User ID.
 * @return WP_Post|null
 */
function cc_researcher_for_user( $user_id ) {
	if ( ! $user_id ) {
		return null;
	}
	$found = get_posts(
		array(
			'post_type'        => 'researcher',
			'post_status'      => 'publish',
			'numberposts'      => 1,
			'meta_key'         => 'cc_user_id', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'       => (int) $user_id, // phpcs:ignore WordPress.DB.SlowDBQuery
			'suppress_filters' => false,
		)
	);
	return $found ? $found[0] : null;
}

/**
 * Author archives redirect (301) to the author's researcher page.
 */
function cc_author_redirect() {
	if ( ! is_author() ) {
		return;
	}
	$author     = get_queried_object();
	$researcher = $author instanceof WP_User ? cc_researcher_for_user( $author->ID ) : null;
	if ( $researcher ) {
		wp_safe_redirect( get_permalink( $researcher ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'cc_author_redirect' );
