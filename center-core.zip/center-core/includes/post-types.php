<?php
/**
 * Content types: researcher, activity, event, exhibit (spec §8.2).
 *
 * @package center-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Hebrew labels for a post type.
 *
 * @param string $plural   Plural name.
 * @param string $singular Singular name.
 * @return array
 */
function cc_type_labels( $plural, $singular ) {
	return array(
		'name'          => $plural,
		'singular_name' => $singular,
		'menu_name'     => $plural,
		'add_new'       => 'הוספה',
		'add_new_item'  => 'הוספת ' . $singular,
		'edit_item'     => 'עריכת ' . $singular,
		'new_item'      => $singular . ' חדש',
		'view_item'     => 'צפייה ב' . $singular,
		'search_items'  => 'חיפוש ' . $plural,
		'not_found'     => 'לא נמצאו פריטים',
		'all_items'     => 'כל ה' . $plural,
	);
}

/**
 * Post type definitions. Kept in one place so roles.php can read them.
 *
 * @return array slug => args
 */
function cc_post_type_defs() {
	$common = array(
		'public'       => true,
		'show_in_rest' => true,
		'has_archive'  => true,
		'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
		'menu_position' => 21,
	);
	return array(
		'researcher' => array_merge(
			$common,
			array(
				'labels'    => cc_type_labels( 'חוקרים', 'חוקר' ),
				'rewrite'   => array( 'slug' => 'researchers', 'with_front' => false ),
				'rest_base' => 'researchers',
				'menu_icon' => 'dashicons-id',
			)
		),
		'activity'   => array_merge(
			$common,
			array(
				'labels'    => cc_type_labels( 'פעילויות', 'פעילות' ),
				'rewrite'   => array( 'slug' => 'activities', 'with_front' => false ),
				'rest_base' => 'activities',
				'menu_icon' => 'dashicons-groups',
			)
		),
		'event'      => array_merge(
			$common,
			array(
				'labels'    => cc_type_labels( 'אירועים', 'אירוע' ),
				'rewrite'   => array( 'slug' => 'events', 'with_front' => false ),
				'rest_base' => 'events',
				'menu_icon' => 'dashicons-calendar-alt',
			)
		),
		'exhibit'    => array_merge(
			$common,
			array(
				'labels'    => cc_type_labels( 'מוצג החודש', 'מוצג' ),
				'rewrite'   => array( 'slug' => 'exhibit', 'with_front' => false ),
				'rest_base' => 'exhibits',
				'menu_icon' => 'dashicons-format-image',
			)
		),
	);
}

/**
 * Registers the four content types.
 */
function cc_register_post_types() {
	foreach ( cc_post_type_defs() as $slug => $args ) {
		register_post_type( $slug, apply_filters( 'cc_post_type_args', $args, $slug ) );
	}
}
add_action( 'init', 'cc_register_post_types', 5 );

/**
 * Registers post meta used by templates.
 */
function cc_register_meta() {
	$string = array(
		'type'          => 'string',
		'single'        => true,
		'show_in_rest'  => true,
		'default'       => '',
		'auth_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
	);
	$fields = array(
		'researcher' => array( 'cc_title', 'cc_institution' ),
		'activity'   => array( 'cc_duration', 'cc_location', 'cc_lecturer', 'cc_price' ),
		'event'      => array( 'cc_event_date', 'cc_event_time', 'cc_location', 'cc_registration_url' ),
	);
	foreach ( $fields as $type => $keys ) {
		foreach ( $keys as $key ) {
			register_post_meta( $type, $key, array_merge( $string, array( 'sanitize_callback' => 'cc_event_date' === $key ? 'cc_sanitize_date' : 'sanitize_text_field' ) ) );
		}
	}
	register_post_meta(
		'researcher',
		'cc_user_id',
		array_merge( $string, array( 'type' => 'integer', 'default' => 0, 'sanitize_callback' => 'cc_sanitize_user_id' ) )
	);
}
add_action( 'init', 'cc_register_meta', 6 );

/**
 * Keeps only real Y-m-d dates; anything else becomes '' (an event without a
 * valid date would silently drop out of both the upcoming and the past list).
 *
 * @param mixed $value Raw value.
 * @return string
 */
function cc_sanitize_date( $value ) {
	$value = trim( (string) $value );
	$date  = DateTime::createFromFormat( '!Y-m-d', $value );
	return ( $date && $date->format( 'Y-m-d' ) === $value ) ? $value : '';
}

/**
 * Keeps only IDs of existing users; anything else becomes 0.
 *
 * @param mixed $value Raw value.
 * @return int
 */
function cc_sanitize_user_id( $value ) {
	$id = absint( $value );
	return ( $id && get_userdata( $id ) ) ? $id : 0;
}
