<?php
/**
 * Editor fields for the meta the templates use: event date/time/location/
 * registration link, activity details, researcher role/institution/user link.
 * Plain meta boxes (no JavaScript); values go through the registered sanitizers.
 *
 * @package center-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Field definitions per post type: key => [label, input type].
 *
 * @return array
 */
function cc_meta_box_fields() {
	return array(
		'event'      => array(
			'cc_event_date'       => array( 'תאריך', 'date' ),
			'cc_event_time'       => array( 'שעה', 'text' ),
			'cc_location'         => array( 'מקום', 'text' ),
			'cc_registration_url' => array( 'קישור להרשמה', 'url' ),
		),
		'activity'   => array(
			'cc_duration' => array( 'משך', 'text' ),
			'cc_location' => array( 'מקום', 'text' ),
			'cc_lecturer' => array( 'מרצה', 'text' ),
			'cc_price'    => array( 'מחיר (ריק = לא מוצג)', 'text' ),
		),
		'researcher' => array(
			'cc_title'       => array( 'תפקיד', 'text' ),
			'cc_institution' => array( 'מוסד', 'text' ),
			'cc_user_id'     => array( 'חשבון באתר (למאמרים שלו)', 'user' ),
		),
	);
}

/**
 * Adds one "פרטים" box per content type.
 */
function cc_add_meta_boxes() {
	foreach ( array_keys( cc_meta_box_fields() ) as $type ) {
		add_meta_box( 'cc-details', 'פרטים', 'cc_render_meta_box', $type, 'normal', 'high' );
	}
}
add_action( 'add_meta_boxes', 'cc_add_meta_boxes' );

/**
 * Renders the fields.
 *
 * @param WP_Post $post Post.
 */
function cc_render_meta_box( $post ) {
	$fields = cc_meta_box_fields();
	wp_nonce_field( 'cc_meta_box', 'cc_meta_box_nonce' );
	echo '<table class="form-table" role="presentation">';
	foreach ( $fields[ $post->post_type ] as $key => $def ) {
		$value = get_post_meta( $post->ID, $key, true );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $def[0] ) . '</label></th><td>';
		if ( 'user' === $def[1] ) {
			echo '<select id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '"><option value="0">— ללא —</option>';
			foreach ( get_users( array( 'role__in' => array( 'administrator', 'editor', 'author' ), 'orderby' => 'display_name' ) ) as $user ) {
				echo '<option value="' . (int) $user->ID . '"' . selected( (int) $value, $user->ID, false ) . '>' . esc_html( $user->display_name ) . '</option>';
			}
			echo '</select>';
		} else {
			echo '<input id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" type="' . esc_attr( $def[1] ) . '" class="regular-text" value="' . esc_attr( (string) $value ) . '">';
		}
		echo '</td></tr>';
	}
	echo '</table>';
}

/**
 * Saves the fields (meta box form submit).
 *
 * @param int     $post_id Post ID.
 * @param WP_Post $post    Post.
 */
function cc_save_meta_box( $post_id, $post ) {
	$fields = cc_meta_box_fields();
	if ( ! isset( $fields[ $post->post_type ], $_POST['cc_meta_box_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['cc_meta_box_nonce'] ) ), 'cc_meta_box' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	foreach ( array_keys( $fields[ $post->post_type ] ) as $key ) {
		if ( isset( $_POST[ $key ] ) ) {
			// The registered sanitize_callback runs inside update_post_meta.
			update_post_meta( $post_id, $key, wp_unslash( $_POST[ $key ] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		}
	}
}
add_action( 'save_post', 'cc_save_meta_box', 10, 2 );
