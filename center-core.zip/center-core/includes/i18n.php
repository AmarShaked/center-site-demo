<?php
/**
 * Bilingual helpers: fixed UI strings and the main navigation per language
 * (spec: Hebrew default, English under /en/ via Polylang).
 *
 * @package center-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Current language slug: 'he' or 'en'.
 *
 * @return string
 */
function cc_lang() {
	if ( function_exists( 'pll_current_language' ) ) {
		$lang = pll_current_language( 'slug' );
		if ( 'en' === $lang ) {
			return 'en';
		}
	}
	return 'he';
}

/**
 * A fixed UI string in the current language.
 *
 * @param string $he Hebrew.
 * @param string $en English.
 * @return string
 */
function cc_t( $he, $en ) {
	return 'en' === cc_lang() ? $en : $he;
}

/**
 * Points the main navigation block (class cc-main-nav) at the menu of the
 * current language (options cc_nav_he / cc_nav_en).
 *
 * @param array $parsed_block Parsed block.
 * @return array
 */
function cc_swap_nav_ref( $parsed_block ) {
	if ( 'core/navigation' !== $parsed_block['blockName'] ) {
		return $parsed_block;
	}
	$class = isset( $parsed_block['attrs']['className'] ) ? $parsed_block['attrs']['className'] : '';
	if ( false === strpos( ' ' . $class . ' ', ' cc-main-nav ' ) ) {
		return $parsed_block;
	}
	$ref = (int) get_option( 'cc_nav_' . cc_lang() );
	if ( $ref ) {
		$parsed_block['attrs']['ref'] = $ref;
	}
	return $parsed_block;
}
add_filter( 'render_block_data', 'cc_swap_nav_ref' );
