<?php
/**
 * Second seed request: Polylang now boots with its languages, so its rewrite
 * rules (/en/...) exist and can be flushed. Never deploy this file.
 */
if ( ! defined( 'ABSPATH' ) ) {
	require_once '/wordpress/wp-load.php';
}
// Polylang's first-activation wizard redirect sends non-admins to a page
// they cannot open (403 on every admin screen). Live Polylang is set up already.
delete_transient( 'pll_activation_redirect' );
/* ---------- Newsletter forms (Contact Form 7), one per language ---------- */
if ( ! class_exists( 'WPCF7_ContactForm' ) ) {
	error_log( 'cc seed: Contact Form 7 not loaded' );
} else {
	$cc_forms = array(
		'he' => '<label>שם [text* your-name autocomplete:name]</label><label>דוא"ל [email* your-email autocomplete:email]</label>[submit "הרשמה"]',
		'en' => '<label>Name [text* your-name autocomplete:name]</label><label>Email [email* your-email autocomplete:email]</label>[submit "Sign up"]',
	);
	foreach ( $cc_forms as $cc_lang_slug => $cc_markup ) {
		$cc_form = WPCF7_ContactForm::get_template( array( 'title' => 'newsletter-' . $cc_lang_slug ) );
		$cc_form->set_properties( array( 'form' => $cc_markup ) );
		// hash() is empty until the form is reloaded; the numeric ID works in the shortcode.
		update_option( 'cc_newsletter_form_' . $cc_lang_slug, (string) $cc_form->save() );
	}
	// Activity booking forms (spec §9), labels wrap fields for accessible names.
	$cc_booking = array(
		'he' => '<label>סוג פעילות [select* activity-type "הרצאה" "סדנה" "השתלמות מורים" "סיור" "פעילות לתלמידים"]</label>'
			. '<label>נושא [text activity-topic]</label>'
			. '<label>קהל יעד [select* audience "קהל רחב" "מבוגרים וקבוצות" "מורים" "משפחות ותלמידים"]</label>'
			. '<label>מספר משתתפים [number participants min:1]</label>'
			. '<label>תאריך מבוקש [date preferred-date]</label>'
			. '<label>מקום [text place]</label>'
			. '<label>שם מלא [text* your-name autocomplete:name]</label>'
			. '<label>טלפון [tel* your-phone autocomplete:tel]</label>'
			. '<label>דוא"ל [email* your-email autocomplete:email]</label>'
			. '[submit "שליחת בקשה"]',
		'en' => '<label>Activity type [select* activity-type "Lecture" "Workshop" "Teacher training" "Tour" "Student activity"]</label>'
			. '<label>Topic [text activity-topic]</label>'
			. '<label>Audience [select* audience "General public" "Adults and groups" "Teachers" "Families and students"]</label>'
			. '<label>Participants [number participants min:1]</label>'
			. '<label>Preferred date [date preferred-date]</label>'
			. '<label>Place [text place]</label>'
			. '<label>Full name [text* your-name autocomplete:name]</label>'
			. '<label>Phone [tel* your-phone autocomplete:tel]</label>'
			. '<label>Email [email* your-email autocomplete:email]</label>'
			. '[submit "Send request"]',
	);
	foreach ( $cc_booking as $cc_lang_slug => $cc_markup ) {
		$cc_form = WPCF7_ContactForm::get_template( array( 'title' => 'activity-booking-' . $cc_lang_slug ) );
		$cc_form->set_properties( array( 'form' => $cc_markup ) );
		update_option( 'cc_booking_form_' . $cc_lang_slug, (string) $cc_form->save() );
	}
}

do_action( 'cc_playground_finish' );
// Readiness marker lives in the (fresh) database, not on disk: Playground can
// serve leftover upload files from an earlier boot before the seed has run.
if ( ! ( defined( 'CC_DEMO' ) && CC_DEMO ) ) {
	$cc_ready = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'cc-ready', 'post_name' => 'cc-ready', 'post_content' => 'ok' ) );
	if ( function_exists( 'pll_set_post_language' ) ) {
		pll_set_post_language( $cc_ready, 'he' );
	}
}
flush_rewrite_rules( false );
