<?php
/**
 * Plugin Name: Center Demo Content
 * Description: ממלא אתר דמו בתוכן לדוגמה, פעם אחת, בהפעלה. לא להתקין באתר האמיתי. מפעילים אחרי Polylang, Contact Form 7 ו-Center Core.
 * Version: 0.1.0
 * Requires at least: 7.1
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 *
 * @package center-demo
 */

defined( 'ABSPATH' ) || exit;

define( 'CC_DEMO', true );
define( 'CC_DEMO_DIR', __DIR__ );

/**
 * Seeds the demo content once (playground/seed.php in demo mode).
 */
function cc_demo_activate() {
	if ( ! function_exists( 'cc_lang' ) || ! class_exists( 'PLL_Admin_Model' ) || ! class_exists( 'WPCF7_ContactForm' ) ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die( 'קודם מפעילים את Polylang, את Contact Form 7 ואת Center Core, ורק אחר כך את Center Demo Content.', '', array( 'back_link' => true ) );
	}
	if ( get_option( 'cc_demo_seeded' ) ) {
		return;
	}
	// Content types are registered on init; make sure they exist in this request.
	cc_register_post_types();
	cc_register_taxonomies();
	cc_seed_terms();
	require __DIR__ . '/seed.php';
	update_option( 'cc_demo_seeded', 1 );
	update_option( 'cc_demo_finish_pending', 1 );
}
register_activation_hook( __FILE__, 'cc_demo_activate' );

/**
 * Second step on the next admin request, once Polylang boots with its
 * languages: forms, rewrite rules (playground/finish.php in demo mode).
 */
function cc_demo_finish() {
	if ( ! get_option( 'cc_demo_finish_pending' ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	delete_option( 'cc_demo_finish_pending' );
	require __DIR__ . '/finish.php';
}
add_action( 'admin_init', 'cc_demo_finish' );
