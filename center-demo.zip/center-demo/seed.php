<?php
/**
 * Local Playground seed. Runs once per preview boot (the Playground site is
 * fresh on every start). Also shipped inside the one-off "Center Demo" plugin
 * (CC_DEMO) to fill a demo site: test users, passwords and test fixtures are
 * then skipped. Never install on the real site.
 */

if ( ! defined( 'ABSPATH' ) ) {
	require_once '/wordpress/wp-load.php';
}
require_once ABSPATH . 'wp-admin/includes/user.php';
require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';

$cc_demo = defined( 'CC_DEMO' ) && CC_DEMO;
$cc_dir  = defined( 'CC_DEMO_DIR' ) ? CC_DEMO_DIR : WP_CONTENT_DIR . '/cc-playground';
$cc_seed = json_decode( file_get_contents( $cc_dir . '/seed-content.json' ), true );

update_option( 'permalink_structure', '/%postname%/' );
update_option( 'uploads_use_yearmonth_folders', 0 );
update_option( 'blogname', 'המרכז לתולדות הטבע במורשת ישראל' );
update_option( 'blogdescription', 'טבע · מורשת · זהות' );

/* ---------- Polylang: he (default) + en ---------- */
// Polylang only boots its front-end API once a language exists, so build the
// admin model directly (Polylang 3.9: Options object + model->languages).
global $cc_pll; // the demo plugin includes this file inside a function
$cc_pll = null;
if ( class_exists( 'PLL_Admin_Model' ) && class_exists( 'WP_Syntex\\Polylang\\Options\\Options' ) ) {
	$cc_pll_options = new WP_Syntex\Polylang\Options\Options();
	$cc_pll         = new PLL_Admin_Model( $cc_pll_options );
	$cc_langs       = array(
		array( 'name' => 'עברית', 'slug' => 'he', 'locale' => 'he_IL', 'rtl' => true, 'term_group' => 0, 'flag' => 'il' ),
		array( 'name' => 'English', 'slug' => 'en', 'locale' => 'en_US', 'rtl' => false, 'term_group' => 1, 'flag' => 'us' ),
	);
	foreach ( $cc_langs as $cc_args ) {
		if ( ! $cc_pll->languages->get( $cc_args['slug'] ) ) {
			$cc_res = $cc_pll->languages->add( $cc_args );
			if ( is_wp_error( $cc_res ) ) {
				error_log( 'cc seed polylang: ' . $cc_res->get_error_message() );
			}
		}
	}
	$cc_pll_options['default_lang'] = 'he';
	$cc_pll_options['hide_default'] = true;
	$cc_pll_options['force_lang']   = 1;
	$cc_pll_options['rewrite']      = true;
	// Options::save() only persists on shutdown in some contexts; write it now.
	update_option( 'polylang', $cc_pll_options->get_all() );
	$cc_pll->clean_languages_cache();
}

function cc_seed_lang( $post_id, $lang ) {
	global $cc_pll;
	if ( $cc_pll ) {
		$cc_pll->post->set_language( $post_id, $lang );
	}
}
function cc_seed_translations( $ids ) {
	global $cc_pll;
	if ( $cc_pll ) {
		$cc_pll->post->save_translations( reset( $ids ), $ids );
	}
}
function cc_seed_lang_term( $term_id, $lang ) {
	global $cc_pll;
	if ( $cc_pll ) {
		$cc_pll->term->set_language( $term_id, $lang );
	}
}

/* ---------- Users + application passwords (local preview only) ---------- */
if ( $cc_demo ) {
	$cc_admins    = get_users( array( 'role' => 'administrator', 'number' => 1 ) );
	$cc_admin     = get_current_user_id() ? wp_get_current_user() : $cc_admins[0];
	$cc_author_id = 0;
	$cc_creds     = array();
} else {
$cc_admin = get_user_by( 'login', 'admin' );
wp_set_password( 'password', $cc_admin->ID );
$cc_author_id = username_exists( 'author1' );
if ( ! $cc_author_id ) {
	$cc_author_id = wp_insert_user(
		array(
			'user_login'   => 'author1',
			'user_pass'    => 'password',
			'user_email'   => 'author1@example.test',
			'display_name' => 'חוקר לדוגמה',
			'role'         => 'author',
		)
	);
}
$cc_creds = array();
foreach ( array( 'admin' => $cc_admin->ID, 'author1' => $cc_author_id ) as $login => $uid ) {
	$created            = WP_Application_Passwords::create_new_application_password( $uid, array( 'name' => 'cc-tests' ) );
	$cc_creds[ $login ] = array( 'login' => $login, 'appPassword' => $created[0] );
}
}

/* ---------- Categories ---------- */
$cc_cat_map = array();
foreach ( $cc_seed['categories'] as $cat ) {
	if ( 'uncategorized' === $cat['slug'] ) {
		continue;
	}
	$term = wp_insert_term( $cat['name'], 'category', array( 'slug' => $cat['slug'] ) );
	if ( ! is_wp_error( $term ) ) {
		$cc_cat_map[ $cat['id'] ] = $term['term_id'];
		cc_seed_lang_term( $term['term_id'], 'en' === substr( $cat['slug'], -2 ) ? 'en' : 'he' );
	}
}

/* ---------- Posts + pages (same slugs => same URLs) ---------- */
foreach ( $cc_seed['posts'] as $p ) {
	if ( $cc_demo && 'tekhelet-2024' === $p['slug'] ) {
		continue; // test post
	}
	$cats = array();
	foreach ( $p['categories'] as $old ) {
		if ( isset( $cc_cat_map[ $old ] ) ) {
			$cats[] = $cc_cat_map[ $old ];
		}
	}
	$id = wp_insert_post(
		array(
			'post_type'     => 'post',
			'post_status'   => 'publish',
			'post_title'    => $p['title'],
			'post_name'     => $p['slug'],
			'post_content'  => $p['content'],
			'post_excerpt'  => wp_strip_all_tags( $p['excerpt'] ),
			'post_date'     => $p['date'],
			'post_author'   => $cc_admin->ID,
			'post_category' => $cats,
		)
	);
	cc_seed_lang( $id, 'he' );
}
foreach ( $cc_seed['pages'] as $p ) {
	$id = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $p['title'],
			'post_name'    => $p['slug'],
			'post_content' => $p['content'],
			'post_author'  => $cc_admin->ID,
		)
	);
	cc_seed_lang( $id, 'he' );
}

/* ---------- Section pages (site map) + English translations with live slugs ---------- */
// Live English slugs differ from Hebrew ones (Polylang free: unique slugs).
$cc_pairs = array(
	array( 'center', 'אודות המרכז', 'center-en', 'About the center' ),
	array( 'research', 'מחקר ופרסומים', 'research-en', 'Research' ),
	array( 'news', 'כנסים וחדשות', 'news-en', 'Events and news' ),
	array( 'museum', 'המוזיאון והאוספים', 'museum-en', 'Museum' ),
	array( 'support', 'שותפות ותרומות', 'support-en', 'Support' ),
	array( 'accessibility', 'הצהרת נגישות', 'accessibility-en', 'Accessibility statement' ),
	array( 'privacy', 'מדיניות פרטיות', 'privacy-en', 'Privacy policy' ),
	array( 'terms', 'תנאי שימוש', 'terms-en', 'Terms of use' ),
);
foreach ( $cc_pairs as $cc_pair ) {
	$cc_he_id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $cc_pair[0], 'post_title' => $cc_pair[1], 'post_content' => '<p>' . $cc_pair[1] . '</p>' ) );
	cc_seed_lang( $cc_he_id, 'he' );
	$cc_en_id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $cc_pair[2], 'post_title' => $cc_pair[3], 'post_content' => '<p>' . $cc_pair[3] . '</p>' ) );
	cc_seed_lang( $cc_en_id, 'en' );
	cc_seed_translations( array( 'he' => $cc_he_id, 'en' => $cc_en_id ) );
}
// English versions of existing pages, with the live English slugs.
foreach ( array( 'about' => array( 'about-zohar-amar', 'About Prof. Zohar Amar' ), 'contact' => array( 'contact-us', 'Contact Us' ), 'books' => array( 'books-and-pamphlets', 'Books and pamphlets' ), 'credits' => array( 'credits-en', 'Credits' ) ) as $cc_he_slug => $cc_en ) {
	$cc_he_page = get_page_by_path( $cc_he_slug );
	if ( ! $cc_he_page ) {
		continue;
	}
	$cc_en_id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $cc_en[0], 'post_title' => $cc_en[1], 'post_content' => '<p>' . $cc_en[1] . '</p>' ) );
	cc_seed_lang( $cc_en_id, 'en' );
	cc_seed_translations( array( 'he' => $cc_he_page->ID, 'en' => $cc_en_id ) );
}

// Review Focus 1: a Hebrew title that starts with a Latin word (local tests only).
if ( ! $cc_demo ) {
$cc_latin_first = wp_insert_post( array( 'post_type' => 'post', 'post_status' => 'publish', 'post_title' => 'DNA עתיק מגלה סודות חדשים', 'post_name' => 'dna-atik', 'post_content' => '<p>בדיקת כיוון.</p>', 'post_date' => '2026-11-02 10:00:00' ) );
cc_seed_lang( $cc_latin_first, 'he' );
}

/* ---------- One English post: Polylang hides languages with no content ---------- */
$cc_en_post = wp_insert_post(
	array(
		'post_type'    => 'post',
		'post_status'  => 'publish',
		'post_title'   => 'Studies in Nature and Realia',
		'post_name'    => 'studies-in-nature-and-realia-sample',
		'post_content' => '<p>Sample English post for the local preview.</p>',
		'post_author'  => $cc_admin->ID,
	)
);
cc_seed_lang( $cc_en_post, 'en' );

/* ---------- Mosaic images at the same upload paths as live ---------- */
$cc_uploads = wp_upload_dir();
foreach ( $cc_seed['mosaic'] as $file ) {
	$src  = $cc_dir . '/media/' . $file;
	$dest = $cc_uploads['basedir'] . '/' . $file;
	if ( file_exists( $src ) && ! file_exists( $dest ) ) {
		copy( $src, $dest );
		$att = wp_insert_attachment(
			array(
				'post_mime_type' => 'image/jpeg',
				'post_title'     => pathinfo( $file, PATHINFO_FILENAME ),
				'post_status'    => 'inherit',
			),
			$dest
		);
		update_post_meta( $att, '_wp_attached_file', $file );
	}
}

/* ---------- Main navigation per language (spec: site map, 7 items + sub-items) ---------- */
function cc_seed_nav( $title, $items ) {
	$blocks = '';
	foreach ( $items as $label => $def ) {
		list( $url, $children ) = $def;
		$link = sprintf( '{"label":"%s","url":"%s","kind":"custom"}', esc_attr( $label ), esc_url( $url ) );
		if ( $children ) {
			$blocks .= '<!-- wp:navigation-submenu ' . $link . ' -->';
			foreach ( $children as $c_label => $c_url ) {
				$blocks .= sprintf( '<!-- wp:navigation-link {"label":"%s","url":"%s","kind":"custom"} /-->', esc_attr( $c_label ), esc_url( $c_url ) );
			}
			$blocks .= '<!-- /wp:navigation-submenu -->';
		} else {
			$blocks .= '<!-- wp:navigation-link ' . $link . ' /-->';
		}
	}
	return wp_insert_post( array( 'post_type' => 'wp_navigation', 'post_status' => 'publish', 'post_title' => $title, 'post_content' => $blocks ) );
}
$cc_nav_he = cc_seed_nav(
	'תפריט ראשי',
	array(
		'אודות המרכז'       => array( '/center/', array( 'חזון ומטרות' => '/center/#vision', 'מייסד המרכז' => '/about/', 'המועצה המדעית' => '/researchers/#council' ) ),
		'מחקר ופרסומים'     => array( '/research/', array( 'תחומי מחקר' => '/research/', 'מאמרים' => '/articles/', 'ספרים וחוברות' => '/books/', 'שו"ת קדמוניות' => '/faq/' ) ),
		'חוקרי המרכז'       => array( '/researchers/', array() ),
		'פעילויות והדרכה'   => array( '/activities/', array( 'קטלוג פעילויות' => '/activities/', 'הזמנת פעילות' => '/activities/#booking' ) ),
		'כנסים וחדשות'      => array( '/news/', array( 'לוח אירועים' => '/events/', 'כנסים שהתקיימו' => '/events/?past=1' ) ),
		'המוזיאון והאוספים' => array( '/museum/', array( 'מוצג החודש' => '/exhibit/' ) ),
		'שותפות ותרומות'    => array( '/support/', array() ),
	)
);
$cc_nav_en = cc_seed_nav(
	'Main menu',
	array(
		'About'         => array( '/en/center-en/', array( 'Vision' => '/en/center-en/#vision', 'Founder' => '/en/about-zohar-amar/' ) ),
		'Research'      => array( '/en/research-en/', array( 'Books' => '/en/books-and-pamphlets/' ) ),
		'Researchers'   => array( '/researchers/', array() ),
		'Activities'    => array( '/activities/', array( 'Book an activity' => '/activities/#booking' ) ),
		'Events & News' => array( '/en/news-en/', array( 'Events' => '/events/' ) ),
		'Museum'        => array( '/en/museum-en/', array() ),
		'Support'       => array( '/en/support-en/', array() ),
	)
);
update_option( 'cc_nav_he', $cc_nav_he );
update_option( 'cc_nav_en', $cc_nav_en );

// Task 6 fixture pages: hide-empty sections and the upcoming-events query.
function cc_seed_section_page( $slug, $post_type, $heading, $extra = '' ) {
	$query   = wp_json_encode( array_merge( array( 'postType' => $post_type, 'perPage' => 3, 'inherit' => false ), $extra ? array( 'ccEvents' => $extra ) : array() ) );
	$content = '<!-- wp:group {"className":"cc-hide-when-empty"} --><div class="wp-block-group cc-hide-when-empty">'
		. '<!-- wp:heading --><h2 class="wp-block-heading">' . $heading . '</h2><!-- /wp:heading -->'
		. '<!-- wp:query {"queryId":9,"query":' . $query . '} --><div class="wp-block-query"><!-- wp:post-template --><!-- wp:post-title /--><!-- /wp:post-template --></div><!-- /wp:query -->'
		. '</div><!-- /wp:group -->';
	$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $slug, 'post_name' => $slug, 'post_content' => $content ) );
	cc_seed_lang( $id, 'he' );
}
if ( ! $cc_demo ) {
	cc_seed_section_page( 'cc-test-empty', 'exhibit', 'כותרת אזור ריק' );
	cc_seed_section_page( 'cc-test-full', 'post', 'כותרת אזור מלא' );
	cc_seed_section_page( 'cc-test-upcoming', 'event', 'אירועים קרובים', 'upcoming' );
}

/* ---------- Home page data (Task 8) ---------- */
// Only numbers already known (spec: 110 articles, 5 council members); the rest come from the center.
update_option(
	'cc_stats',
	array(
		array( '110', 'מאמרים באתר', 'Articles on the site' ),
		array( '5', 'חברי המועצה המדעית', 'Scientific council members' ),
	)
);
wp_insert_post(
	array(
		'post_type'    => 'event',
		'post_status'  => 'publish',
		'post_title'   => 'יום עיון: צבעים ומלאכות קדומות',
		'post_content' => '<p>אירוע לדוגמה בתצוגה המקומית.</p>',
		'meta_input'   => array( 'cc_event_date' => wp_date( 'Y-m-d', strtotime( '+30 days' ) ), 'cc_location' => 'נוה צוף' ),
	)
);

/* ---------- Researchers, activities, events (Task 10) ---------- */
function cc_seed_term_id( $name, $tax ) {
	$t = get_term_by( 'name', $name, $tax );
	return $t ? (int) $t->term_id : 0;
}
$cc_r1 = wp_insert_post( array( 'post_type' => 'researcher', 'post_status' => 'publish', 'post_title' => 'ד"ר עמיתה לדוגמה', 'post_excerpt' => 'חוקרת צבעים טבעיים ומלאכות קדומות.', 'post_content' => '<p>עמוד חוקר לדוגמה בתצוגה המקומית.</p>', 'meta_input' => array( 'cc_title' => 'חוקרת בכירה', 'cc_institution' => 'אוניברסיטה לדוגמה', 'cc_user_id' => (int) $cc_author_id ) ) );
wp_set_object_terms( $cc_r1, array( cc_seed_term_id( 'חוקרים ועמיתי מחקר', 'researcher_group' ) ), 'researcher_group' );
$cc_r2 = wp_insert_post( array( 'post_type' => 'researcher', 'post_status' => 'publish', 'post_title' => "פרופ' חבר מועצה", 'post_content' => '<p>חבר המועצה המדעית.</p>', 'meta_input' => array( 'cc_title' => 'חבר המועצה המדעית' ) ) );
wp_set_object_terms( $cc_r2, array( cc_seed_term_id( 'המועצה המדעית', 'researcher_group' ) ), 'researcher_group' );

$cc_a1 = wp_insert_post( array( 'post_type' => 'activity', 'post_status' => 'publish', 'post_title' => 'סדנת צבעים טבעיים', 'post_excerpt' => 'היכרות עם חומרי הצביעה הקדומים והדגמת הפקת צבע.', 'meta_input' => array( 'cc_duration' => 'שעתיים', 'cc_location' => 'נוה צוף', 'cc_lecturer' => 'ד"ר עמיתה לדוגמה' ) ) );
wp_set_object_terms( $cc_a1, array( cc_seed_term_id( 'סדנה', 'activity_type' ) ), 'activity_type' );
wp_set_object_terms( $cc_a1, array( cc_seed_term_id( 'משפחות ותלמידים', 'audience' ) ), 'audience' );
wp_set_object_terms( $cc_a1, array( cc_seed_term_id( 'צבעים ומלאכות קדומות', 'research_area' ) ), 'research_area' );
$cc_a2 = wp_insert_post( array( 'post_type' => 'activity', 'post_status' => 'publish', 'post_title' => 'הרצאה: קטורת ובשמים', 'post_excerpt' => 'זיהוי סממני הקטורת ומסחר הבשמים בעולם הקדום.', 'meta_input' => array( 'cc_duration' => 'שעה וחצי', 'cc_location' => 'בתיאום', 'cc_price' => '450 ₪' ) ) );
wp_set_object_terms( $cc_a2, array( cc_seed_term_id( 'הרצאה', 'activity_type' ) ), 'activity_type' );
wp_set_object_terms( $cc_a2, array( cc_seed_term_id( 'קהל רחב', 'audience' ) ), 'audience' );
wp_set_object_terms( $cc_a2, array( cc_seed_term_id( 'רפואה בשמים וקטורת', 'research_area' ) ), 'research_area' );

wp_insert_post( array( 'post_type' => 'event', 'post_status' => 'publish', 'post_title' => 'כנס שהתקיים', 'post_content' => '<p>כנס לדוגמה שכבר התקיים.</p>', 'meta_input' => array( 'cc_event_date' => wp_date( 'Y-m-d', strtotime( '-60 days' ) ), 'cc_location' => 'ירושלים' ) ) );

/* ---------- Hook for later tasks' seed data ---------- */
do_action( 'cc_playground_seed', $cc_admin->ID, $cc_author_id );

if ( ! $cc_demo ) {
	file_put_contents( $cc_uploads['basedir'] . '/cc-test-creds.json', wp_json_encode( $cc_creds ) );
}
// finish.php (next blueprint step, a fresh request with Polylang fully booted)
// flushes rewrite rules and writes cc-ready.txt.
