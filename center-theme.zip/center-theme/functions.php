<?php
/**
 * Center Theme setup.
 *
 * @package center-theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Front-end and editor styles that theme.json cannot express.
 */
function cc_theme_assets() {
	$ver = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'center-theme-site', get_theme_file_uri( 'assets/css/site.css' ), array(), $ver );
}
add_action( 'wp_enqueue_scripts', 'cc_theme_assets' );

/**
 * Same styles inside the editor.
 */
function cc_theme_setup() {
	add_editor_style( 'assets/css/site.css' );
}
add_action( 'after_setup_theme', 'cc_theme_setup' );

/**
 * A fixed string in the current language (falls back to Hebrew without center-core).
 *
 * @param string $he Hebrew.
 * @param string $en English.
 * @return string
 */
function cc_tt( $he, $en ) {
	return function_exists( 'cc_t' ) ? cc_t( $he, $en ) : $he;
}

/**
 * URL path prefix of the current language: '' for Hebrew, '/en' for English.
 *
 * @return string
 */
function cc_lang_prefix() {
	return ( function_exists( 'cc_lang' ) && 'en' === cc_lang() ) ? '/en' : '';
}

/**
 * Site URL for a path in the current language.
 *
 * @param string $path Path starting with '/'.
 * @return string
 */
function cc_url( $path ) {
	return home_url( cc_lang_prefix() . $path );
}

/**
 * Brand colour of a post's first research area (gold, olive, forest, sky), or cream.
 *
 * @param int $post_id Post ID.
 * @return string Palette slug.
 */
function cc_area_color( $post_id ) {
	$order = array(
		'צבעים ומלאכות קדומות'   => 'gold',
		'רפואה בשמים וקטורת'     => 'olive',
		'חקלאות ומזון קדום'      => 'forest',
		'בעלי חיים ומסורות ישראל' => 'sky',
	);
	$terms = taxonomy_exists( 'research_area' ) ? get_the_terms( $post_id, 'research_area' ) : false;
	if ( $terms && ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			if ( isset( $order[ $term->name ] ) ) {
				return $order[ $term->name ];
			}
		}
	}
	return 'cream';
}

/**
 * Cards whose post has no featured image get a brand-colour tile instead of nothing.
 *
 * @param string   $content  Rendered block.
 * @param array    $block    Parsed block.
 * @param WP_Block $instance Block instance.
 * @return string
 */
function cc_featured_image_fallback( $content, $block, $instance ) {
	$class = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( '' !== trim( $content ) || false === strpos( $class, 'cc-card__media' ) ) {
		return $content;
	}
	$post_id = isset( $instance->context['postId'] ) ? (int) $instance->context['postId'] : get_the_ID();
	return sprintf(
		'<figure class="wp-block-post-featured-image cc-card__media cc-tile is-%s" aria-hidden="true"></figure>',
		esc_attr( cc_area_color( $post_id ) )
	);
}
add_filter( 'render_block_core/post-featured-image', 'cc_featured_image_fallback', 10, 3 );

/**
 * Fills the empty group with class cc-author-box on single posts: the linked
 * researcher (photo, name, title, link), else the WP user's name and bio.
 *
 * @param string $content Rendered block.
 * @param array  $block   Parsed block.
 * @return string
 */
function cc_render_author_box( $content, $block ) {
	$class = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( 'core/group' !== $block['blockName'] || false === strpos( ' ' . $class . ' ', ' cc-author-box ' ) || ! is_singular( 'post' ) ) {
		return $content;
	}
	$post       = get_queried_object();
	$author_id  = (int) $post->post_author;
	$researcher = function_exists( 'cc_researcher_for_user' ) ? cc_researcher_for_user( $author_id ) : null;
	if ( $researcher ) {
		$name  = get_the_title( $researcher );
		$role  = (string) get_post_meta( $researcher->ID, 'cc_title', true );
		$bio   = get_the_excerpt( $researcher );
		$link  = get_permalink( $researcher );
		$photo = get_the_post_thumbnail( $researcher, 'thumbnail', array( 'class' => 'cc-author-box__photo', 'alt' => '' ) );
	} else {
		$name  = get_the_author_meta( 'display_name', $author_id );
		$role  = '';
		$bio   = get_the_author_meta( 'description', $author_id );
		$link  = '';
		$photo = '';
	}
	$html  = '<aside class="wp-block-group cc-author-box" aria-label="' . esc_attr( cc_tt( 'על הכותב', 'About the author' ) ) . '">';
	$html .= $photo;
	$html .= '<div class="cc-author-box__text"><p class="cc-author-box__label">' . esc_html( cc_tt( 'נכתב על ידי', 'Written by' ) ) . '</p>';
	$html .= '<p class="cc-author-box__name">' . esc_html( $name ) . '</p>';
	if ( $role ) {
		$html .= '<p class="cc-author-box__role">' . esc_html( $role ) . '</p>';
	}
	if ( $bio ) {
		$html .= '<p class="cc-author-box__bio">' . esc_html( $bio ) . '</p>';
	}
	if ( $link ) {
		$html .= '<a class="cc-author-box__link" href="' . esc_url( $link ) . '">' . esc_html( cc_tt( 'לעמוד החוקר', 'Researcher page' ) ) . '</a>';
	}
	return $html . '</div></aside>';
}
add_filter( 'render_block', 'cc_render_author_box', 10, 2 );

/**
 * Query Loops with query.ccRelated show 3 posts from the current post's categories.
 *
 * @param array    $query Query vars.
 * @param WP_Block $block Post-template block.
 * @return array
 */
function cc_related_query_vars( $query, $block ) {
	if ( empty( $block->context['query']['ccRelated'] ) || ! is_singular() ) {
		return $query;
	}
	$id                      = get_queried_object_id();
	$query['category__in']   = wp_get_post_categories( $id );
	$query['post__not_in']   = array( $id );
	$query['posts_per_page'] = 3;
	return $query;
}
add_filter( 'query_loop_block_query_vars', 'cc_related_query_vars', 10, 2 );

/**
 * Fills an empty group with class cc-meta-list with the current item's details
 * (activity, event or researcher). Empty values are left out.
 *
 * @param string   $content  Rendered block.
 * @param array    $block    Parsed block.
 * @param WP_Block $instance Block instance.
 * @return string
 */
function cc_render_meta_list( $content, $block, $instance ) {
	$class = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( 'core/group' !== $block['blockName'] || false === strpos( ' ' . $class . ' ', ' cc-meta-list ' ) ) {
		return $content;
	}
	$id   = isset( $instance->context['postId'] ) ? (int) $instance->context['postId'] : get_queried_object_id();
	$type = get_post_type( $id );
	$meta = function ( $key ) use ( $id ) {
		return trim( (string) get_post_meta( $id, $key, true ) );
	};
	$rows = array();
	if ( 'activity' === $type ) {
		foreach ( array( 'activity_type', 'audience' ) as $tax ) {
			$terms = get_the_terms( $id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$label = 'activity_type' === $tax ? cc_tt( 'סוג', 'Type' ) : cc_tt( 'קהל יעד', 'Audience' );
				$rows[ $tax ] = array( $label, implode( ', ', wp_list_pluck( $terms, 'name' ) ) );
			}
		}
		$rows['duration'] = array( cc_tt( 'משך', 'Duration' ), $meta( 'cc_duration' ) );
		$rows['location'] = array( cc_tt( 'מקום', 'Location' ), $meta( 'cc_location' ) );
		$rows['lecturer'] = array( cc_tt( 'מרצה', 'Lecturer' ), $meta( 'cc_lecturer' ) );
		$rows['price']    = array( cc_tt( 'מחיר', 'Price' ), $meta( 'cc_price' ) );
	} elseif ( 'event' === $type ) {
		$date = $meta( 'cc_event_date' );
		$ts   = $date ? strtotime( $date . ' 12:00:00' ) : 0;
		$rows['date']     = array( cc_tt( 'תאריך', 'Date' ), $ts ? wp_date( cc_tt( 'j בF Y', 'F j, Y' ), $ts ) : '' );
		$rows['time']     = array( cc_tt( 'שעה', 'Time' ), $meta( 'cc_event_time' ) );
		$rows['location'] = array( cc_tt( 'מקום', 'Location' ), $meta( 'cc_location' ) );
	} elseif ( 'researcher' === $type ) {
		$rows['title']       = array( cc_tt( 'תפקיד', 'Role' ), $meta( 'cc_title' ) );
		$rows['institution'] = array( cc_tt( 'מוסד', 'Institution' ), $meta( 'cc_institution' ) );
	}
	$html = '';
	foreach ( $rows as $key => $row ) {
		if ( '' !== $row[1] ) {
			$html .= '<div class="cc-meta cc-meta--' . esc_attr( $key ) . '"><dt>' . esc_html( $row[0] ) . '</dt><dd>' . esc_html( $row[1] ) . '</dd></div>';
		}
	}
	if ( 'event' === $type ) {
		$date = $meta( 'cc_event_date' );
		$url  = $meta( 'cc_registration_url' );
		$past = $date && $date < wp_date( 'Y-m-d' );
		$tail = $past ? '<p class="cc-event-past">' . esc_html( cc_tt( 'האירוע התקיים', 'This event has taken place' ) ) . '</p>' : '';
		if ( ! $past && $url && is_singular( 'event' ) ) {
			$tail .= '<p><a class="wp-block-button__link wp-element-button" href="' . esc_url( $url ) . '">' . esc_html( cc_tt( 'להרשמה', 'Register' ) ) . '</a></p>';
		}
		return '<div class="cc-meta-list">' . ( $html ? '<dl>' . $html . '</dl>' : '' ) . $tail . '</div>';
	}
	return $html ? '<div class="cc-meta-list"><dl>' . $html . '</dl></div>' : '';
}
add_filter( 'render_block', 'cc_render_meta_list', 10, 3 );

/**
 * Query Loops with query.ccResearcherPosts list posts by the researcher's linked user.
 *
 * @param array    $query Query vars.
 * @param WP_Block $block Post-template block.
 * @return array
 */
function cc_researcher_posts_query_vars( $query, $block ) {
	if ( empty( $block->context['query']['ccResearcherPosts'] ) ) {
		return $query;
	}
	$user = (int) get_post_meta( get_queried_object_id(), 'cc_user_id', true );
	$query['author']   = $user ? $user : -1;
	$query['post__in'] = $user ? array() : array( 0 );
	return $query;
}
add_filter( 'query_loop_block_query_vars', 'cc_researcher_posts_query_vars', 10, 2 );

/**
 * Link targets the theme prints, by key. Pages come from Settings → הגדרות המרכז
 * (option cc_page_<key>) or, if unset, the Hebrew page at the given path; in
 * English the page's Polylang translation is used when it exists. Archives of
 * the (untranslated) content types are language-neutral.
 *
 * @return array key => [ 'page'|'archive', path or post type ]
 */
function cc_link_targets() {
	return array(
		'center'        => array( 'page', 'center' ),
		'research'      => array( 'page', 'research' ),
		'news'          => array( 'page', 'news' ),
		'museum'        => array( 'page', 'museum' ),
		'support'       => array( 'page', 'support' ),
		'about'         => array( 'page', 'about' ),
		'books'         => array( 'page', 'books' ),
		'contact'       => array( 'page', 'contact' ),
		'credits'       => array( 'page', 'credits' ),
		'privacy'       => array( 'page', 'privacy' ),
		'terms'         => array( 'page', 'terms' ),
		'accessibility' => array( 'page', 'accessibility' ),
		'activities'    => array( 'archive', 'activity' ),
		'events'        => array( 'archive', 'event' ),
		'researchers'   => array( 'archive', 'researcher' ),
		'exhibits'      => array( 'archive', 'exhibit' ),
	);
}

/**
 * URL for a link key in the current language, or '' when the target does not
 * exist (callers then leave the link out instead of printing a broken one).
 *
 * @param string $key Key from cc_link_targets().
 * @return string
 */
function cc_link( $key ) {
	$targets = cc_link_targets();
	if ( ! isset( $targets[ $key ] ) ) {
		return '';
	}
	list( $kind, $target ) = $targets[ $key ];
	if ( 'archive' === $kind ) {
		$url = post_type_exists( $target ) ? get_post_type_archive_link( $target ) : '';
		return $url ? $url : '';
	}
	$id = (int) get_option( 'cc_page_' . $key );
	if ( ! $id ) {
		$page = get_page_by_path( $target );
		$id   = $page ? (int) $page->ID : 0;
	}
	if ( ! $id || 'publish' !== get_post_status( $id ) ) {
		return '';
	}
	if ( function_exists( 'pll_get_post' ) && function_exists( 'cc_lang' ) ) {
		$translated = pll_get_post( $id, cc_lang() );
		if ( $translated && 'publish' === get_post_status( $translated ) ) {
			$id = (int) $translated;
		}
	}
	return (string) get_permalink( $id );
}

/**
 * A core/button block linking to a key, or '' when the target is missing.
 *
 * @param string $key     Link key.
 * @param string $label   Button text (already in the current language).
 * @param bool   $outline Outline style.
 * @param string $hash    Optional fragment, e.g. '#booking'.
 * @return string
 */
function cc_button( $key, $label, $outline = false, $hash = '' ) {
	$url = cc_link( $key );
	if ( ! $url ) {
		return '';
	}
	$class = $outline ? ' is-style-outline' : '';
	$attrs = $outline ? ' {"className":"is-style-outline"}' : '';
	return '<!-- wp:button' . $attrs . ' --><div class="wp-block-button' . $class . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $url . $hash ) . '">' . esc_html( $label ) . '</a></div><!-- /wp:button -->';
}

/**
 * Server-rendered wrapper for the theme's dynamic PHP patterns. Template parts
 * and templates use this block instead of core/pattern so that saving them in
 * the Site Editor keeps the reference (the editor would otherwise freeze the
 * pattern's rendered, language-specific output into static blocks).
 */
function cc_register_dynamic_block() {
	wp_register_script(
		'center-theme-dynamic-block',
		get_theme_file_uri( 'assets/js/dynamic-block.js' ),
		array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-block-editor' ),
		wp_get_theme()->get( 'Version' ),
		true
	);
	register_block_type(
		'center-theme/dynamic',
		array(
			'api_version'     => 3,
			'title'           => 'Center: dynamic section',
			'category'        => 'theme',
			'attributes'      => array( 'pattern' => array( 'type' => 'string', 'default' => '' ) ),
			'supports'        => array( 'html' => false, 'inserter' => false, 'reusable' => false ),
			'editor_script'   => 'center-theme-dynamic-block',
			'render_callback' => 'cc_render_dynamic_block',
		)
	);
}
add_action( 'init', 'cc_register_dynamic_block' );

/**
 * Renders a registered theme pattern at request time.
 *
 * @param array $attributes Block attributes.
 * @return string
 */
function cc_render_dynamic_block( $attributes ) {
	$slug = isset( $attributes['pattern'] ) ? (string) $attributes['pattern'] : '';
	if ( 0 !== strpos( $slug, 'center-theme/' ) ) {
		return '';
	}
	$pattern = WP_Block_Patterns_Registry::get_instance()->get_registered( $slug );
	return $pattern ? do_blocks( $pattern['content'] ) : '';
}
