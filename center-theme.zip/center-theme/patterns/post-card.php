<?php
/**
 * Title: Post card
 * Slug: center-theme/post-card
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:group {"className":"cc-card","layout":{"type":"default"}} -->
<div class="wp-block-group cc-card">
<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/10","className":"cc-card__media"} /-->
<!-- wp:group {"className":"cc-card__body","layout":{"type":"default"}} -->
<div class="wp-block-group cc-card__body">
<!-- wp:post-title {"level":3,"isLink":true,"className":"cc-card__title"} /-->
<!-- wp:post-excerpt {"excerptLength":20,"className":"cc-card__excerpt"} /-->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
