<?php
/**
 * Title: Research areas (four brand-colour cards)
 * Slug: center-theme/research-areas
 * Categories: featured
 *
 * @package center-theme
 */

$cc_areas = array(
	array( 'צבעים ומלאכות קדומות', 'Ancient dyes and crafts', 'תכלת, ארגמן, שני וטכנולוגיות ייצור', 'Tekhelet, argaman, crimson and ancient technologies', 'gold' ),
	array( 'רפואה בשמים וקטורת', 'Medicine, perfume and incense', 'סממני מרפא, בושם ומסורות עתיקות', 'Medicinal materials, perfume and ancient traditions', 'olive' ),
	array( 'חקלאות ומזון קדום', 'Ancient agriculture and food', 'גידולים, תזונה ושחזור מזונות', 'Crops, diet and reconstructed foods', 'forest' ),
	array( 'בעלי חיים ומסורות ישראל', 'Animals and Jewish traditions', 'זואולוגיה, כשרות וזיהוי בעלי חיים', 'Zoology, kashrut and identifying animals', 'sky' ),
);
?>
<!-- wp:group {"align":"wide","className":"cc-section cc-areas","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cc-section cc-areas">
<!-- wp:heading {"className":"cc-section__title"} -->
<h2 class="wp-block-heading cc-section__title"><?php echo esc_html( cc_tt( 'תחומי המחקר שלנו', 'Our research areas' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:html -->
<ul class="cc-areas__grid">
<?php
foreach ( $cc_areas as $cc_area ) :
	$cc_term = get_term_by( 'name', $cc_area[0], 'research_area' );
	$cc_link = ( $cc_term && ! is_wp_error( $cc_term ) ) ? get_term_link( $cc_term ) : cc_link( 'research' );
	$cc_link = is_wp_error( $cc_link ) ? '' : $cc_link;
	?>
	<li class="cc-area-card is-<?php echo esc_attr( $cc_area[4] ); ?>">
		<a href="<?php echo esc_url( $cc_link ? $cc_link : cc_url( '/' ) ); ?>">
			<span class="cc-area-card__tile"><span class="cc-area-card__name"><?php echo esc_html( cc_tt( $cc_area[0], $cc_area[1] ) ); ?></span></span>
			<span class="cc-area-card__desc"><?php echo esc_html( cc_tt( $cc_area[2], $cc_area[3] ) ); ?></span>
		</a>
	</li>
<?php endforeach; ?>
</ul>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
