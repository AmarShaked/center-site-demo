<?php
/**
 * Title: Search form
 * Slug: center-theme/search-form
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:search {"label":"<?php echo esc_attr( cc_tt( 'חיפוש באתר', 'Search the site' ) ); ?>","showLabel":false,"buttonText":"<?php echo esc_attr( cc_tt( 'חיפוש', 'Search' ) ); ?>","className":"cc-search-page"} /-->
