<?php
/**
 * Title: Posts by this researcher
 * Slug: center-theme/researcher-posts
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:group {"align":"wide","className":"cc-section cc-researcher-posts cc-hide-when-empty","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cc-section cc-researcher-posts cc-hide-when-empty">
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html( cc_tt( 'מאמרים', 'Articles' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:query {"queryId":45,"query":{"perPage":12,"postType":"post","inherit":false,"ccResearcherPosts":true}} -->
<div class="wp-block-query"><!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:pattern {"slug":"center-theme/post-card"} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
</div>
<!-- /wp:group -->
