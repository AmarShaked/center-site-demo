<?php
/**
 * Title: No results
 * Slug: center-theme/no-results
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:paragraph -->
<p><?php echo esc_html( cc_tt( 'לא נמצאו פריטים.', 'Nothing found.' ) ); ?></p>
<!-- /wp:paragraph -->
