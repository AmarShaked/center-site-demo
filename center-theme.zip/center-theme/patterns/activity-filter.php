<?php
/**
 * Title: Activity filter (plain links, no JavaScript)
 * Slug: center-theme/activity-filter
 * Inserter: no
 *
 * @package center-theme
 */

$cc_current = get_queried_object();
$cc_rows    = array(
	'activity_type' => cc_tt( 'סוג פעילות', 'Activity type' ),
	'audience'      => cc_tt( 'קהל יעד', 'Audience' ),
);
$cc_all     = get_post_type_archive_link( 'activity' );
?>
<!-- wp:html -->
<nav class="cc-filter" aria-label="<?php echo esc_attr( cc_tt( 'סינון פעילויות', 'Filter activities' ) ); ?>">
<?php foreach ( $cc_rows as $cc_tax => $cc_label ) : ?>
	<?php
	$cc_terms = get_terms( array( 'taxonomy' => $cc_tax, 'hide_empty' => false ) );
	if ( is_wp_error( $cc_terms ) ) {
		continue;
	}
	?>
	<div class="cc-filter__row">
		<span class="cc-filter__label"><?php echo esc_html( $cc_label ); ?></span>
		<ul>
			<li><a href="<?php echo esc_url( $cc_all ); ?>"<?php echo is_post_type_archive( 'activity' ) ? ' aria-current="page"' : ''; ?>><?php echo esc_html( cc_tt( 'הכל', 'All' ) ); ?></a></li>
			<?php foreach ( $cc_terms as $cc_term ) : ?>
			<li><a href="<?php echo esc_url( get_term_link( $cc_term ) ); ?>"<?php echo ( $cc_current instanceof WP_Term && $cc_current->term_id === $cc_term->term_id ) ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $cc_term->name ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</div>
<?php endforeach; ?>
</nav>
<!-- /wp:html -->
