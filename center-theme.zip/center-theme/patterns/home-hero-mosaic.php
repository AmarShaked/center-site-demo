<?php
/**
 * Title: Home hero with collection mosaic (B3)
 * Slug: center-theme/home-hero-mosaic
 * Categories: banner
 *
 * @package center-theme
 */

$cc_img = function ( $file, $alt, $class = '' ) {
	return sprintf(
		'<!-- wp:image {"sizeSlug":"large","className":"cc-mosaic__img %3$s"} --><figure class="wp-block-image size-large cc-mosaic__img %3$s"><img src="%1$s" alt="%2$s" loading="eager"/></figure><!-- /wp:image -->',
		esc_url( content_url( 'uploads/' . $file ) ),
		esc_attr( $alt ),
		esc_attr( $class )
	);
};
?>
<!-- wp:group {"align":"wide","className":"cc-hero","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cc-hero">
<!-- wp:group {"className":"cc-hero__text","layout":{"type":"default"}} -->
<div class="wp-block-group cc-hero__text">
<!-- wp:paragraph {"className":"cc-kicker"} -->
<p class="cc-kicker"><?php echo esc_html( cc_tt( 'המרכז לתולדות הטבע במורשת ישראל', 'The Center for Natural History in Jewish Heritage' ) ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"cc-hero__title"} -->
<h1 class="wp-block-heading cc-hero__title"><?php echo esc_html( cc_tt( 'מחקר, חינוך ומורשת, בעקבות הטבע בארץ ישראל הקדומה', 'Research, education and heritage, following nature in ancient Israel' ) ); ?></h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"cc-lead"} -->
<p class="cc-lead"><?php echo esc_html( cc_tt( 'מחקרים, ספרים ואוספים, ומוזיאון חי שעתיד לקום בנוה צוף.', 'Research, books and collections, and a living museum to be built in Neve Tsuf.' ) ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><?php echo cc_button( 'research', cc_tt( 'למחקרי המרכז', 'Our research' ), false ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo cc_button( 'activities', cc_tt( 'לפעילויות', 'Activities' ), true ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"cc-mosaic","layout":{"type":"default"}} -->
<div class="wp-block-group cc-mosaic">
<?php
echo $cc_img( 'תמר-פירות-1024x768.jpg', cc_tt( 'אשכולות תמרים על העץ', 'Date clusters on the palm' ), 'is-large' ); // phpcs:ignore WordPress.Security.EscapeOutput
?>
<!-- wp:group {"className":"cc-mosaic__tile is-gold"} --><div class="wp-block-group cc-mosaic__tile is-gold"></div><!-- /wp:group -->
<?php
echo $cc_img( 'תמונה-34-1-1024x681.jpg', cc_tt( 'חוטי צמר צבועים בצבעים טבעיים', 'Wool threads dyed with natural dyes' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
?>
<!-- wp:group {"className":"cc-mosaic__tile is-sky"} --><div class="wp-block-group cc-mosaic__tile is-sky"></div><!-- /wp:group -->
<?php
echo $cc_img( 'חיטה3-1024x768.jpg', cc_tt( 'שיבולי חיטה', 'Ears of wheat' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
echo $cc_img( 'תמונה-5-1024x732.jpg', cc_tt( 'אתרוגים', 'Etrogs' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
?>
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
