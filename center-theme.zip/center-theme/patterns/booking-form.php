<?php
/**
 * Title: Activity booking form
 * Slug: center-theme/booking-form
 * Inserter: no
 *
 * @package center-theme
 */

$cc_form = (string) get_option( 'cc_booking_form_' . ( function_exists( 'cc_lang' ) ? cc_lang() : 'he' ) );
?>
<!-- wp:group {"anchor":"booking","className":"cc-section cc-booking","backgroundColor":"white","layout":{"type":"constrained","contentSize":"640px"}} -->
<div id="booking" class="wp-block-group cc-section cc-booking has-white-background-color has-background">
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html( cc_tt( 'הזמנת פעילות', 'Book an activity' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><?php echo esc_html( cc_tt( 'ספרו לנו מה אתם מחפשים ונחזור אליכם עם הצעה.', 'Tell us what you are looking for and we will get back to you.' ) ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:html -->
<?php
if ( $cc_form && shortcode_exists( 'contact-form-7' ) ) {
	echo do_shortcode( '[contact-form-7 id="' . esc_attr( $cc_form ) . '" html_class="cc-form"]' ); // phpcs:ignore WordPress.Security.EscapeOutput -- CF7 markup
}
?>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
