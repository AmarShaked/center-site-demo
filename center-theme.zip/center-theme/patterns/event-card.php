<?php
/**
 * Title: Event card
 * Slug: center-theme/event-card
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:group {"className":"cc-card cc-event-card","layout":{"type":"default"}} -->
<div class="wp-block-group cc-card cc-event-card">
<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/10","className":"cc-card__media"} /-->
<!-- wp:group {"className":"cc-card__body","layout":{"type":"default"}} -->
<div class="wp-block-group cc-card__body">
<!-- wp:post-title {"level":3,"isLink":true,"className":"cc-card__title"} /-->
<!-- wp:group {"className":"cc-meta-list"} --><div class="wp-block-group cc-meta-list"></div><!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
