<?php
/**
 * Title: From the library (latest articles)
 * Slug: center-theme/from-the-library
 * Categories: query
 *
 * @package center-theme
 */
?>
<!-- wp:group {"align":"wide","className":"cc-section cc-library cc-hide-when-empty","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cc-section cc-library cc-hide-when-empty">
<!-- wp:heading {"className":"cc-section__title"} -->
<h2 class="wp-block-heading cc-section__title"><?php echo esc_html( cc_tt( 'מן הספרייה: קדמוניות הטבע', 'From the library' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:query {"queryId":24,"query":{"perPage":3,"postType":"post","order":"desc","orderBy":"date","inherit":false}} -->
<div class="wp-block-query"><!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:pattern {"slug":"center-theme/post-card"} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><?php echo cc_button( 'books', cc_tt( 'לספרים', 'Books' ), true ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
