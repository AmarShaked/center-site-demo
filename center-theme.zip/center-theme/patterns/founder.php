<?php
/**
 * Title: Founder
 * Slug: center-theme/founder
 * Categories: about
 *
 * @package center-theme
 */
?>
<!-- wp:group {"align":"wide","className":"cc-section cc-founder","layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignwide cc-section cc-founder">
<!-- wp:heading {"className":"cc-section__title"} -->
<h2 class="wp-block-heading cc-section__title"><?php echo esc_html( cc_tt( 'מייסד המרכז', 'Founder of the center' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><?php echo esc_html( cc_tt( 'פרופ\' זהר עמר הוא מייסד המרכז והדמות המדעית המובילה בו. מחקריו עוסקים בטבע ובריאליה של ארץ ישראל במקורות ישראל.', 'Prof. Zohar Amar is the founder of the center and its leading scientific figure. His research deals with the nature and realia of the Land of Israel in Jewish sources.' ) ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><?php echo cc_button( 'about', cc_tt( 'לעמוד המייסד', 'About the founder' ), false ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo cc_button( 'researchers', cc_tt( 'לחוקרי המרכז', 'Our researchers' ), true ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
