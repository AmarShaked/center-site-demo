<?php
/**
 * Title: Researchers archive (two groups)
 * Slug: center-theme/researchers-archive
 * Inserter: no
 *
 * @package center-theme
 */

$cc_groups = array(
	array( 'חוקרים ועמיתי מחקר', 'Researchers and research fellows', 'fellows' ),
	array( 'המועצה המדעית', 'Scientific council', 'council' ),
);
foreach ( $cc_groups as $cc_i => $cc_group ) :
	$cc_term = get_term_by( 'name', $cc_group[0], 'researcher_group' );
	if ( ! $cc_term ) {
		continue;
	}
	?>
<!-- wp:group {"anchor":"<?php echo esc_attr( $cc_group[2] ); ?>","className":"cc-section cc-researchers cc-researchers--<?php echo esc_attr( $cc_group[2] ); ?> cc-hide-when-empty","layout":{"type":"default"}} -->
<div id="<?php echo esc_attr( $cc_group[2] ); ?>" class="wp-block-group cc-section cc-researchers cc-researchers--<?php echo esc_attr( $cc_group[2] ); ?> cc-hide-when-empty">
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html( cc_tt( $cc_group[0], $cc_group[1] ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:query {"queryId":<?php echo 40 + (int) $cc_i; ?>,"query":{"perPage":100,"postType":"researcher","order":"asc","orderBy":"title","inherit":false,"taxQuery":{"researcher_group":[<?php echo (int) $cc_term->term_id; ?>]}}} -->
<div class="wp-block-query"><!-- wp:post-template {"layout":{"type":"grid","columnCount":4}} -->
<!-- wp:pattern {"slug":"center-theme/researcher-card"} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
</div>
<!-- /wp:group -->
<?php endforeach; ?>
