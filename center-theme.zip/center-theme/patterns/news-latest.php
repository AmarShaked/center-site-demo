<?php
/**
 * Title: What's new (latest from the whats-new category)
 * Slug: center-theme/news-latest
 * Categories: query
 *
 * @package center-theme
 */

$cc_cat = get_category_by_slug( 'whats-new' );
$cc_tax = $cc_cat ? ',"taxQuery":{"category":[' . (int) $cc_cat->term_id . ']}' : '';
?>
<!-- wp:group {"align":"wide","className":"cc-section cc-news cc-hide-when-empty","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cc-section cc-news cc-hide-when-empty">
<!-- wp:heading {"className":"cc-section__title"} -->
<h2 class="wp-block-heading cc-section__title"><?php echo esc_html( cc_tt( 'מה מתחדש במרכז?', "What's new at the center?" ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:query {"queryId":21,"query":{"perPage":3,"postType":"post","order":"desc","orderBy":"date","inherit":false<?php echo $cc_tax; // phpcs:ignore WordPress.Security.EscapeOutput ?>}} -->
<div class="wp-block-query"><!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:pattern {"slug":"center-theme/post-card"} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $cc_cat ? get_category_link( $cc_cat ) : cc_link( 'news' ) ); ?>"><?php echo esc_html( cc_tt( 'לכל החדשות', 'All news' ) ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
