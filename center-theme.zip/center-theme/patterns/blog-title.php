<?php
/**
 * Title: Articles index title
 * Slug: center-theme/blog-title
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading"><?php echo esc_html( cc_tt( 'מאמרים', 'Articles' ) ); ?></h1>
<!-- /wp:heading -->
