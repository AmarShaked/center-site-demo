<?php
/**
 * Title: Related posts (same categories)
 * Slug: center-theme/related-posts
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:group {"align":"wide","className":"cc-section cc-related cc-hide-when-empty","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cc-section cc-related cc-hide-when-empty">
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html( cc_tt( 'מאמרים נוספים', 'More articles' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:query {"queryId":31,"query":{"perPage":3,"postType":"post","inherit":false,"ccRelated":true}} -->
<div class="wp-block-query"><!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:pattern {"slug":"center-theme/post-card"} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
</div>
<!-- /wp:group -->
