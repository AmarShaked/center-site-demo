<?php
/**
 * Title: Header bar
 * Slug: center-theme/header-bar
 * Inserter: no
 *
 * @package center-theme
 */

$cc_he   = function_exists( 'cc_t' );
$cc_text = function ( $he, $en ) use ( $cc_he ) {
	return $cc_he ? cc_t( $he, $en ) : $he;
};
$cc_home = function_exists( 'pll_home_url' ) ? pll_home_url() : home_url( '/' );
$cc_lang = function_exists( 'cc_lang' ) ? cc_lang() : 'he';
$cc_name = $cc_text( 'המרכז לתולדות הטבע במורשת ישראל', 'The Center for Natural History in Jewish Heritage' );
$cc_nav  = (int) get_option( 'cc_nav_he' );
$cc_switch = function_exists( 'pll_the_languages' )
	? pll_the_languages(
		array(
			'dropdown'      => 0,
			'show_names'    => 1,
			'show_flags'    => 0,
			'hide_current'  => 1,
			'hide_if_empty' => 0,
			'echo'          => 0,
		)
	)
	: '';
?>
<!-- wp:group {"className":"cc-header","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group cc-header">
<!-- wp:group {"className":"cc-header__bar","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"center"}} -->
<div class="wp-block-group cc-header__bar">
<!-- wp:html -->
<a class="cc-logo" href="<?php echo esc_url( $cc_home ); ?>" rel="home"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/logo-color.svg' ) ); ?>" alt="<?php echo esc_attr( $cc_name ); ?>" width="56" height="56"></a>
<!-- /wp:html -->
<!-- wp:navigation {"ref":<?php echo (int) $cc_nav; ?>,"className":"cc-main-nav","overlayMenu":"mobile","layout":{"type":"flex","justifyContent":"left"}} /-->
<!-- wp:group {"className":"cc-header__tools","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group cc-header__tools">
<!-- wp:search {"label":"<?php echo esc_attr( $cc_text( 'חיפוש באתר', 'Search the site' ) ); ?>","showLabel":false,"buttonText":"<?php echo esc_attr( $cc_text( 'חיפוש', 'Search' ) ); ?>","buttonPosition":"button-only","buttonUseIcon":true,"isSearchFieldHidden":true,"className":"cc-search"} /-->
<!-- wp:html -->
<ul class="cc-lang-switch" aria-label="<?php echo esc_attr( $cc_text( 'שפה', 'Language' ) ); ?>"><?php echo $cc_switch; // phpcs:ignore WordPress.Security.EscapeOutput -- Polylang markup ?></ul>
<?php if ( cc_link( 'contact' ) ) : ?><a class="cc-contact" href="<?php echo esc_url( cc_link( 'contact' ) ); ?>"><?php echo esc_html( $cc_text( 'צור קשר', 'Contact' ) ); ?></a><?php endif; ?>
<!-- /wp:html -->
<!-- wp:buttons {"className":"cc-cta"} -->
<div class="wp-block-buttons cc-cta"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( cc_link( 'activities' ) . '#booking' ); ?>"><?php echo esc_html( $cc_text( 'הזמנת פעילות', 'Book an activity' ) ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
