<?php
/**
 * Title: Researcher card
 * Slug: center-theme/researcher-card
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:group {"className":"cc-card cc-researcher-card","layout":{"type":"default"}} -->
<div class="wp-block-group cc-card cc-researcher-card">
<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"1","className":"cc-card__media"} /-->
<!-- wp:group {"className":"cc-card__body","layout":{"type":"default"}} -->
<div class="wp-block-group cc-card__body">
<!-- wp:post-title {"level":3,"isLink":true,"className":"cc-card__title"} /-->
<!-- wp:group {"className":"cc-meta-list"} --><div class="wp-block-group cc-meta-list"></div><!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
