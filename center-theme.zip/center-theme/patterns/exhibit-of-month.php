<?php
/**
 * Title: Exhibit of the month
 * Slug: center-theme/exhibit-of-month
 * Categories: query
 *
 * @package center-theme
 */
?>
<!-- wp:group {"align":"wide","className":"cc-section cc-exhibit cc-hide-when-empty","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cc-section cc-exhibit cc-hide-when-empty">
<!-- wp:heading {"className":"cc-section__title"} -->
<h2 class="wp-block-heading cc-section__title"><?php echo esc_html( cc_tt( 'מוצג החודש', 'Exhibit of the month' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:query {"queryId":23,"query":{"perPage":1,"postType":"exhibit","order":"desc","orderBy":"date","inherit":false}} -->
<div class="wp-block-query"><!-- wp:post-template -->
<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:post-featured-image {"isLink":true,"aspectRatio":"4/3"} /--></div>
<!-- /wp:column --><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:post-title {"level":3,"isLink":true} /--><!-- wp:post-excerpt {"moreText":"<?php echo esc_attr( cc_tt( 'לקריאה נוספת', 'Read more' ) ); ?>"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
</div>
<!-- /wp:group -->
