<?php
/**
 * Title: 404 content
 * Slug: center-theme/not-found
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading"><?php echo esc_html( cc_tt( 'העמוד לא נמצא', 'Page not found' ) ); ?></h1>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><?php echo esc_html( cc_tt( 'ייתכן שהעמוד הועבר. אפשר לחפש באתר או לחזור לעמוד הבית.', 'The page may have moved. Search the site or go back to the home page.' ) ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:pattern {"slug":"center-theme/search-form"} /-->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( function_exists( 'pll_home_url' ) ? pll_home_url() : home_url( '/' ) ); ?>"><?php echo esc_html( cc_tt( 'לעמוד הבית', 'Home page' ) ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
