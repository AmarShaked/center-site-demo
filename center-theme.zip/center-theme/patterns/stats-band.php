<?php
/**
 * Title: The center in numbers
 * Slug: center-theme/stats-band
 * Inserter: no
 *
 * Values come from option cc_stats: a list of [number, Hebrew label, English label].
 * Nothing renders until the center provides real numbers.
 *
 * @package center-theme
 */

$cc_stats = (array) get_option( 'cc_stats', array() );
if ( ! $cc_stats ) {
	return;
}
?>
<!-- wp:html -->
<section class="cc-stats alignwide" aria-label="<?php echo esc_attr( cc_tt( 'המרכז במספרים', 'The center in numbers' ) ); ?>">
	<ul>
	<?php foreach ( $cc_stats as $cc_stat ) : ?>
		<li><span class="cc-stats__num"><?php echo esc_html( $cc_stat[0] ); ?></span><span class="cc-stats__label"><?php echo esc_html( cc_tt( $cc_stat[1], $cc_stat[2] ) ); ?></span></li>
	<?php endforeach; ?>
	</ul>
</section>
<!-- /wp:html -->
