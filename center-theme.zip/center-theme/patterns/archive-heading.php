<?php
/**
 * Title: Archive heading for content types
 * Slug: center-theme/archive-heading
 * Inserter: no
 *
 * @package center-theme
 */

$cc_titles = array(
	'researcher' => array( 'חוקרי המרכז', 'Our researchers' ),
	'activity'   => array( 'פעילויות והדרכה', 'Activities' ),
	'event'      => array( 'לוח אירועים', 'Events' ),
	'exhibit'    => array( 'מוצג החודש', 'Exhibit of the month' ),
);
$cc_type = get_query_var( 'post_type' );
$cc_type = is_array( $cc_type ) ? reset( $cc_type ) : $cc_type;
if ( is_tax( array( 'activity_type', 'audience' ) ) ) {
	$cc_type = 'activity';
}
$cc_title = isset( $cc_titles[ $cc_type ] ) ? cc_tt( $cc_titles[ $cc_type ][0], $cc_titles[ $cc_type ][1] ) : '';
if ( 'event' === $cc_type && isset( $_GET['past'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
	$cc_title = cc_tt( 'כנסים ואירועים שהתקיימו', 'Past events' );
}
if ( is_tax() ) {
	$cc_title .= ': ' . single_term_title( '', false );
}
?>
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading"><?php echo esc_html( $cc_title ); ?></h1>
<!-- /wp:heading -->
<?php if ( 'event' === $cc_type ) : ?>
<!-- wp:html -->
<p class="cc-event-switch"><a href="<?php echo esc_url( get_post_type_archive_link( 'event' ) . ( isset( $_GET['past'] ) ? '' : '?past=1' ) ); // phpcs:ignore WordPress.Security.NonceVerification ?>"><?php echo esc_html( isset( $_GET['past'] ) ? cc_tt( 'לאירועים הקרובים', 'Upcoming events' ) : cc_tt( 'לאירועים שהתקיימו', 'Past events' ) ); // phpcs:ignore WordPress.Security.NonceVerification ?></a></p>
<!-- /wp:html -->
<?php endif; ?>
