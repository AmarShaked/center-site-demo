<?php
/**
 * Title: Upcoming activities and events
 * Slug: center-theme/upcoming-activities
 * Categories: query
 *
 * @package center-theme
 */
?>
<!-- wp:group {"align":"wide","className":"cc-section cc-upcoming cc-hide-when-empty","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cc-section cc-upcoming cc-hide-when-empty">
<!-- wp:heading {"className":"cc-section__title"} -->
<h2 class="wp-block-heading cc-section__title"><?php echo esc_html( cc_tt( 'פעילויות קרובות', 'Upcoming activities' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:query {"queryId":22,"query":{"perPage":3,"postType":"event","inherit":false,"ccEvents":"upcoming"}} -->
<div class="wp-block-query"><!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:pattern {"slug":"center-theme/post-card"} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><?php echo cc_button( 'events', cc_tt( 'ללוח האירועים', 'All events' ), true ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo cc_button( 'activities', cc_tt( 'הזמנת פעילות לקבוצה', 'Book an activity for a group' ), false, '#booking' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
