<?php
/**
 * Title: Newsletter band
 * Slug: center-theme/newsletter-band
 * Categories: call-to-action
 *
 * @package center-theme
 */

$cc_form = (string) get_option( 'cc_newsletter_form_' . ( function_exists( 'cc_lang' ) ? cc_lang() : 'he' ) );
?>
<!-- wp:group {"align":"wide","anchor":"newsletter","className":"cc-section cc-newsletter-band","backgroundColor":"white","layout":{"type":"constrained","contentSize":"640px"}} -->
<div id="newsletter" class="wp-block-group alignwide cc-section cc-newsletter-band has-white-background-color has-background">
<!-- wp:heading {"className":"cc-section__title"} -->
<h2 class="wp-block-heading cc-section__title"><?php echo esc_html( cc_tt( 'הרשמה לעדכונים', 'Stay in touch' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><?php echo esc_html( cc_tt( 'עדכונים על מחקרים, ספרים, כנסים והתקדמות הקמת המוזיאון.', 'News about research, books, conferences and the museum project.' ) ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:html -->
<?php
if ( $cc_form && shortcode_exists( 'contact-form-7' ) ) {
	echo do_shortcode( '[contact-form-7 id="' . esc_attr( $cc_form ) . '" html_class="cc-newsletter cc-newsletter--light"]' ); // phpcs:ignore WordPress.Security.EscapeOutput -- CF7 markup
}
?>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
