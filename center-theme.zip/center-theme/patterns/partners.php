<?php
/**
 * Title: Founding partners (logos)
 * Slug: center-theme/partners
 * Inserter: no
 *
 * Logos from option cc_partners: a list of [name, logo URL, link URL].
 * Nothing renders while the list is empty.
 *
 * @package center-theme
 */

$cc_partners = (array) get_option( 'cc_partners', array() );
if ( ! $cc_partners ) {
	return;
}
?>
<!-- wp:html -->
<section class="cc-section cc-partners alignwide">
	<h2 class="cc-section__title"><?php echo esc_html( cc_tt( 'שותפים להקמת המרכז', 'Founding partners' ) ); ?></h2>
	<ul class="cc-partners__logos">
	<?php foreach ( $cc_partners as $cc_p ) : ?>
		<li><a href="<?php echo esc_url( $cc_p[2] ); ?>"><img src="<?php echo esc_url( $cc_p[1] ); ?>" alt="<?php echo esc_attr( $cc_p[0] ); ?>"></a></li>
	<?php endforeach; ?>
	</ul>
</section>
<!-- /wp:html -->
