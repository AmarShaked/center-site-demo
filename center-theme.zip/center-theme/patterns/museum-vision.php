<?php
/**
 * Title: Museum vision band
 * Slug: center-theme/museum-vision
 * Categories: call-to-action
 *
 * @package center-theme
 */
?>
<!-- wp:group {"align":"full","className":"cc-band cc-museum","backgroundColor":"forest","textColor":"white","layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull cc-band cc-museum has-white-color has-forest-background-color has-text-color has-background">
<!-- wp:heading {"textColor":"white","className":"cc-section__title"} -->
<h2 class="wp-block-heading cc-section__title has-white-color has-text-color"><?php echo esc_html( cc_tt( 'החזון שלנו: מוזיאון חי לתולדות הטבע', 'Our vision: a living museum of natural history' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><?php echo esc_html( cc_tt( 'מרכז מחקר ומורשת בנוה צוף, המשלב תצוגות טבע, אוספים היסטוריים, גן לצמחי תועלת ופעילות חינוכית.', 'A research and heritage center in Neve Tsuf, combining nature displays, historical collections, a garden of useful plants and educational activity.' ) ); ?></p>
<!-- /wp:paragraph -->
<?php $cc_museum = cc_link( 'museum' ); if ( $cc_museum ) : ?>
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"white","textColor":"forest"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-forest-color has-white-background-color has-text-color has-background wp-element-button" href="<?php echo esc_url( $cc_museum ); ?>"><?php echo esc_html( cc_tt( 'לחזון המוזיאון', 'The museum vision' ) ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
<?php endif; ?>
</div>
<!-- /wp:group -->
