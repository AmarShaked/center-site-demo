<?php
/**
 * Title: Activity card
 * Slug: center-theme/activity-card
 * Inserter: no
 *
 * @package center-theme
 */
?>
<!-- wp:group {"className":"cc-card cc-activity-card","layout":{"type":"default"}} -->
<div class="wp-block-group cc-card cc-activity-card">
<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/10","className":"cc-card__media"} /-->
<!-- wp:group {"className":"cc-card__body","layout":{"type":"default"}} -->
<div class="wp-block-group cc-card__body">
<!-- wp:post-title {"level":3,"isLink":true,"className":"cc-card__title"} /-->
<!-- wp:post-excerpt {"excerptLength":24,"className":"cc-card__excerpt"} /-->
<!-- wp:group {"className":"cc-meta-list"} --><div class="wp-block-group cc-meta-list"></div><!-- /wp:group -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#booking"><?php echo esc_html( cc_tt( 'להזמנה', 'Book' ) ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
