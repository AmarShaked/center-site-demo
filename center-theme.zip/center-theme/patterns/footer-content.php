<?php
/**
 * Title: Footer content
 * Slug: center-theme/footer-content
 * Inserter: no
 *
 * @package center-theme
 */

$cc_text = function ( $he, $en ) {
	return function_exists( 'cc_t' ) ? cc_t( $he, $en ) : $he;
};
$cc_lang   = function_exists( 'cc_lang' ) ? cc_lang() : 'he';
$cc_nav    = (int) get_option( 'cc_nav_he' );
$cc_form   = (string) get_option( 'cc_newsletter_form_' . $cc_lang );
$cc_social = array_filter(
	array(
		'YouTube'  => (string) get_option( 'cc_social_youtube' ),
		'Facebook' => (string) get_option( 'cc_social_facebook' ),
	)
);
$cc_entity = (string) get_option( 'cc_legal_entity' );
$cc_contact = cc_link( 'contact' );
$cc_legal  = array(
	$cc_text( 'הצהרת נגישות', 'Accessibility statement' ) => cc_link( 'accessibility' ),
	$cc_text( 'מדיניות פרטיות', 'Privacy policy' )        => cc_link( 'privacy' ),
	$cc_text( 'תנאי שימוש', 'Terms of use' )              => cc_link( 'terms' ),
	$cc_text( 'קרדיטים', 'Credits' )                      => cc_link( 'credits' ),
);
?>
<!-- wp:group {"className":"cc-footer","backgroundColor":"forest","textColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group cc-footer has-white-color has-forest-background-color has-text-color has-background">
<!-- wp:columns {"className":"cc-footer__cols"} -->
<div class="wp-block-columns cc-footer__cols">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:html -->
<img class="cc-footer__logo" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/logo-white.svg' ) ); ?>" alt="" width="96" height="96">
<p class="cc-footer__name"><?php echo esc_html( $cc_text( 'המרכז לתולדות הטבע במורשת ישראל', 'The Center for Natural History in Jewish Heritage' ) ); ?></p>
<p class="cc-footer__tagline"><?php echo esc_html( $cc_text( 'טבע · מורשת · זהות', 'Nature · Heritage · Identity' ) ); ?></p>
<!-- /wp:html -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":2,"className":"cc-footer__title","textColor":"white"} -->
<h2 class="wp-block-heading cc-footer__title has-white-color has-text-color"><?php echo esc_html( $cc_text( 'ניווט מהיר', 'Quick links' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:navigation {"ref":<?php echo (int) $cc_nav; ?>,"className":"cc-main-nav cc-footer-nav","overlayMenu":"never","showSubmenuIcon":false,"layout":{"type":"flex","orientation":"vertical"}} /-->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":2,"className":"cc-footer__title","textColor":"white"} -->
<h2 class="wp-block-heading cc-footer__title has-white-color has-text-color"><?php echo esc_html( $cc_text( 'הרשמה לעדכונים', 'Newsletter' ) ); ?></h2>
<!-- /wp:heading -->
<!-- wp:html -->
<?php
if ( is_front_page() ) {
	// The home page has its own newsletter band (id="newsletter").
	echo '<p><a href="#newsletter">' . esc_html( $cc_text( 'להרשמה לעדכונים', 'Sign up for updates' ) ) . '</a></p>';
} elseif ( $cc_form && shortcode_exists( 'contact-form-7' ) ) {
	echo do_shortcode( '[contact-form-7 id="' . esc_attr( $cc_form ) . '" html_class="cc-newsletter"]' ); // phpcs:ignore WordPress.Security.EscapeOutput -- CF7 markup
}
?>
<?php if ( $cc_contact ) : ?><p class="cc-footer__contact"><a href="<?php echo esc_url( $cc_contact ); ?>"><?php echo esc_html( $cc_text( 'צור קשר', 'Contact us' ) ); ?></a></p><?php endif; ?>
<?php if ( $cc_social ) : ?>
<ul class="cc-footer__social">
	<?php foreach ( $cc_social as $cc_label => $cc_url ) : ?>
	<li><a href="<?php echo esc_url( $cc_url ); ?>" rel="noopener"><?php echo esc_html( $cc_label ); ?></a></li>
	<?php endforeach; ?>
</ul>
<?php endif; ?>
<!-- /wp:html -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
<!-- wp:html -->
<div class="cc-footer__legal">
	<ul>
		<?php foreach ( array_filter( $cc_legal ) as $cc_label => $cc_url ) : ?>
		<li><a href="<?php echo esc_url( $cc_url ); ?>"><?php echo esc_html( $cc_label ); ?></a></li>
		<?php endforeach; ?>
	</ul>
	<?php if ( $cc_entity ) : ?>
	<p><?php echo esc_html( $cc_entity ); ?></p>
	<?php endif; ?>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
