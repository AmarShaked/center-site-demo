<?php
/**
 * Title: Contact form
 * Slug: center-theme/contact-form
 * Inserter: no
 *
 * Renders the Contact Form 7 form whose ID is in option cc_contact_form_he /
 * cc_contact_form_en (set at go-live to the site's existing contact form).
 *
 * @package center-theme
 */

$cc_form = (string) get_option( 'cc_contact_form_' . ( function_exists( 'cc_lang' ) ? cc_lang() : 'he' ) );
?>
<!-- wp:html -->
<?php
if ( $cc_form && shortcode_exists( 'contact-form-7' ) ) {
	echo do_shortcode( '[contact-form-7 id="' . esc_attr( $cc_form ) . '" html_class="cc-form"]' ); // phpcs:ignore WordPress.Security.EscapeOutput -- CF7 markup
} else {
	$cc_contact = cc_link( 'contact' );
	if ( $cc_contact ) {
		echo '<p><a href="' . esc_url( $cc_contact ) . '">' . esc_html( cc_tt( 'ליצירת קשר', 'Contact us' ) ) . '</a></p>';
	}
}
?>
<!-- /wp:html -->
