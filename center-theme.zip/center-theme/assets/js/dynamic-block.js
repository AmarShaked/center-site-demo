// Editor side of center-theme/dynamic: shows the server-rendered section and
// saves nothing but the block comment, so the reference survives edits.
( function ( wp ) {
	var el = wp.element.createElement;
	wp.blocks.registerBlockType( 'center-theme/dynamic', {
		apiVersion: 3,
		title: 'Center: dynamic section',
		category: 'theme',
		attributes: { pattern: { type: 'string', default: '' } },
		supports: { html: false, inserter: false, reusable: false },
		edit: function ( props ) {
			return el(
				'div',
				wp.blockEditor.useBlockProps(),
				el( wp.serverSideRender, { block: 'center-theme/dynamic', attributes: props.attributes } )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
